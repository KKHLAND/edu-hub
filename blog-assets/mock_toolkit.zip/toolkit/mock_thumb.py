import json, sys, html
from playwright.sync_api import sync_playwright

e = lambda s: html.escape(s).replace("\n", "<br>")
NUM = "①②③④⑤"

CSS = """*{margin:0;box-sizing:border-box}
body{width:1200px;height:675px;font-family:'Noto Sans CJK KR',sans-serif;overflow:hidden;position:relative;
background:#f7f3e8;color:#14233c}
.paper{position:absolute;inset:0;background-image:linear-gradient(#e3dcc8 1px,transparent 1px);background-size:100% 44px;opacity:.55}
.margin{position:absolute;left:96px;top:0;bottom:0;width:3px;background:#e46a6a;opacity:.55}
.top{position:absolute;left:0;right:0;top:0;height:74px;background:#14233c;color:#fff;display:flex;align-items:center;
justify-content:space-between;padding:0 56px 0 128px;font-size:24px;font-weight:700;letter-spacing:.5px}
.top .tag{background:#f5c518;color:#14233c;padding:6px 16px;border-radius:6px;font-weight:900}
.left{position:absolute;left:128px;top:122px;width:560px}
.kick{font-size:28px;font-weight:700;color:#3b5b8c}
h1{font-size:68px;line-height:1.18;font-weight:900;margin-top:14px;letter-spacing:-1.5px}
.hl{background:linear-gradient(transparent 58%,#f5c518 58%,#f5c518 92%,transparent 92%)}
.sub{font-size:27px;color:#44536b;margin-top:22px;font-weight:500;line-height:1.5}
.foot{position:absolute;left:128px;bottom:34px;font-size:21px;color:#5b6a80;font-weight:500}
.right{position:absolute;right:56px;top:110px;width:420px;height:510px;background:#fff;border:2px solid #14233c;border-radius:14px;
box-shadow:10px 10px 0 #14233c;padding:22px 26px}
.rh{font-size:22px;font-weight:900;border-bottom:2px solid #14233c;padding-bottom:10px;margin-bottom:12px;display:flex;justify-content:space-between}
.rh span{color:#c0392b}
.row{display:flex;align-items:center;height:41px;font-size:21px}
.row .n{width:46px;font-weight:900}
.b{width:34px;height:34px;border-radius:50%;border:2px solid #9aa6b8;margin-right:12px;display:flex;align-items:center;justify-content:center;
font-size:17px;color:#9aa6b8}
.b.on{background:#14233c;border-color:#14233c;color:#fff}
.row .p{margin-left:auto;font-size:15px;color:#c0392b;font-weight:900}
.card{display:flex;justify-content:space-between;align-items:baseline;border-bottom:1px dashed #b8c0cc;padding:11px 0}
.card b{font-size:27px;font-weight:900;font-family:'Noto Serif CJK KR',serif}
.card span{font-size:21px;color:#44536b}
.cnt{position:absolute;right:26px;bottom:18px;font-size:19px;color:#c0392b;font-weight:900}
"""

def page(spec):
    if spec["kind"] == "answers":
        rows = "".join(
            f'<div class="row"><span class="n">{n}</span>' +
            "".join(f'<span class="b{" on" if i==a else ""}">{i+1}</span>' for i in range(5)) +
            (f'<span class="p">3점</span>' if pt else "") + "</div>"
            for n, a, pt in spec["rows"])
        right = f'<div class="right"><div class="rh">{e(spec.get('head','고난도 문항 정답'))}<span>{e(spec.get('badge',''))}</span></div>{rows}</div>'
    elif spec["kind"] == "list":
        items = "".join(f'<div class="card"><b style="font-family:inherit;font-size:24px">{e(a)}</b><span>{e(b)}</span></div>' for a, b in spec["items"])
        right = f'<div class="right"><div class="rh">{e(spec["head"])}<span>{e(spec["head2"])}</span></div>{items}</div>'
    else:
        cards = "".join(f'<div class="card"><b>{e(w)}</b><span>{e(m)}</span></div>' for w, m in spec["words"])
        right = f'<div class="right"><div class="rh">문항별 핵심 어휘<span>{e(spec.get('range','18~45번'))}</span></div>{cards}<div class="cnt">{e(spec["count"])}</div></div>'
    return f"""<html><head><meta charset="utf-8"><style>{CSS}{spec.get("css","")}</style></head><body>
<div class="paper"></div><div class="margin"></div>
<div class="top"><span>{e(spec.get("brand","고등 영어 모의고사 해설"))}</span><span class="tag">{e(spec['tag'])}</span></div>
<div class="left"><div class="kick">{e(spec['kicker'])}</div><h1>{spec['title']}</h1><div class="sub">{e(spec['sub'])}</div></div>
{right}<div class="foot">{e(spec['foot'])}</div></body></html>"""

if __name__ == "__main__":
    spec = json.load(open(sys.argv[1], encoding="utf-8"))
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1200, "height": 675}, device_scale_factor=1)
        pg.set_content(page(spec))
        pg.screenshot(path=sys.argv[2], type="png")
        b.close()
