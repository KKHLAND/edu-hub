// 티스토리 글쓰기 화면(https://koreaholic.tistory.com/manage/newpost/)에서 실행하는 도우미
// 사용: const prep = eval(localStorage.getItem('__mockPrep')) 또는 아래 함수를 그대로 붙여 넣기
// await prep('T1', '<edu-hub blog-assets 커밋>', 16, 18, 0, '<URL 슬러그>')
// → 대표 이미지 붙여넣기 업로드, 본문·제목·태그 입력, 발행창(공개·예약·날짜·시각·URL·대표이미지)까지 채움.
// '공개 발행' 버튼은 직접 눌러야 하며, 티스토리 보안 확인(DKAPTCHA)은 선생님이 풀어야 함.
const prep = async (key, commit, day, hour, minute, slug, code = '0324g1') => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const base = 'https://cdn.jsdelivr.net/gh/KKHLAND/edu-hub@' + commit + '/blog-assets/' + code + '/';
  const m = (await (await fetch(base + 'meta.json')).json())[key];
  const html = await (await fetch(base + 'post_' + key + '_t.html')).text();
  const ed = tinymce.activeEditor; ed.setContent(''); ed.focus();
  const b = await (await fetch(base + m.img)).blob();
  const mk = () => { const dt = new DataTransfer(); dt.items.add(new File([b], m.img, {type: 'image/png'})); return dt; };
  ed.getBody().dispatchEvent(new ClipboardEvent('paste', {clipboardData: mk(), bubbles: true, cancelable: true}));
  let c = '';
  for (let i = 0; i < 40 && !c.includes('[##_Image'); i++) { await sleep(500); c = ed.getContent(); }
  const img = (c.match(/\[##_Image[\s\S]*?_##\]/) || [''])[0];
  if (!img) return 'image upload failed';
  ed.setContent(html.replace('<!--IMG-->', '<p>' + img + '</p>'));
  const t = document.getElementById('post-title-inp');
  Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set.call(t, m.title); t.dispatchEvent(new Event('input', {bubbles: true}));
  const inp = document.getElementById('tagText'); const iset = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  for (const tg of m.tags) { inp.focus(); iset.call(inp, tg); inp.dispatchEvent(new Event('input', {bubbles: true}));
    for (const ty of ['keydown', 'keypress', 'keyup']) inp.dispatchEvent(new KeyboardEvent(ty, {key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true})); await sleep(150); }
  [...document.querySelectorAll('button')].find(x => x.textContent.trim() === '완료').click(); await sleep(800);
  const dlg = document.querySelector('[role=dialog]');
  dlg.querySelector('#open20').click(); await sleep(300);
  [...dlg.querySelectorAll('button')].find(x => x.textContent.trim() === '예약').click(); await sleep(400);
  if (!dlg.querySelector('.box_calendar')) { dlg.querySelector('.btn_reserve').click(); await sleep(400); }
  // 다음 달 날짜면 .btn_next 를 먼저 눌러야 함
  [...dlg.querySelectorAll('.btn_day')].find(x => x.textContent.trim() === String(day) && !x.disabled).click(); await sleep(300);
  const set = (el, v) => { el.focus(); iset.call(el, String(v)); el.dispatchEvent(new Event('input', {bubbles: true})); el.dispatchEvent(new Event('change', {bubbles: true})); el.blur(); };
  set(dlg.querySelector('#dateHour'), hour); set(dlg.querySelector('#dateMinute'), minute); set(dlg.querySelector('#urlPublish'), slug);
  const fi = dlg.querySelector('input[type=file]'); fi.files = mk().files; fi.dispatchEvent(new Event('change', {bubbles: true})); await sleep(2500);
  return {date: dlg.querySelector('.btn_reserve').textContent.trim(), h: dlg.querySelector('#dateHour').value, url: dlg.querySelector('#urlPublish').value};
};
