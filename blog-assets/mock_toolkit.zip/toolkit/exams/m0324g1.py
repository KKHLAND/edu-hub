# 2026학년도 3월 고1 전국연합학력평가 (2026.3.24) — 영어
META = dict(code="0324g1", label="2026년 3월 고1", date="2026년 3월 24일", grade="고1", month="3월",
            ebsi_path="기출문제 → 전국연합학력평가 → 2026년 → 3월 → 고1 → 영어")

ANS = [int(x) for x in "4 4 4 5 1 3 5 4 4 2 2 1 1 2 2 4 3 2 1 2 5 5 3 5 4 3 4 5 2 3 1 1 2 1 4 3 5 4 3 1 3 5 2 5 3".split()]
ANS = {i + 1: a for i, a in enumerate(ANS)}
PT3 = {6, 12, 14, 21, 24, 29, 33, 34, 38, 42}

# n: (발문, [선택지], 추가 HTML)
Q = {
1: ("다음을 듣고, 남자가 하는 말의 목적으로 가장 적절한 것을 고르시오.", ["축제 공연 일정 변경을 안내하려고","밴드의 신입 부원 모집을 공지하려고","밴드의 경연 대회 우승 소식을 알리려고","축제에서 밴드가 연주할 곡을 추천받으려고","축제에서 지켜야 할 안전 수칙을 설명하려고"], ""),
2: ("대화를 듣고, 여자의 의견으로 가장 적절한 것을 고르시오.", ["높은 강도의 운동을 한 뒤에는 휴식을 취해야 한다.","근육통을 방지하려면 영양을 고르게 섭취해야 한다.","근육 발달을 위해서는 규칙적으로 운동을 해야 한다.","근육통을 줄이기 위해 운동 후 스트레칭을 해야 한다.","운동 종류에 따른 적절한 스트레칭 방식을 익혀야 한다."], ""),
3: ("다음을 듣고, 여자가 하는 말의 요지로 가장 적절한 것을 고르시오.", ["새로운 환경에서는 언행을 신중하게 하는 것이 바람직하다.","침착한 태도는 상대에게 긍정적인 인상을 주어 호감을 높인다.","친구 관계는 서로를 배려하는 과정 속에서 자연스럽게 형성된다.","먼저 인사를 건네는 것은 새로운 관계를 형성하는 데 도움이 된다.","원만한 인간관계를 위해서는 상대의 인사에 적절히 반응해야 한다."], ""),
4: ("대화를 듣고, 그림에서 대화의 내용과 일치하지 않는 것을 고르시오.", [], "<p class='small'>그림: 체육대회 날 운동장 — ① 두 장대 사이의 Blue Team 현수막 ② 의자 위의 모자 ③ 캔을 줍는 여학생 ④ 줄무늬 셔츠 ⑤ 장대 옆의 축구공</p>"),
5: ("대화를 듣고, 남자가 할 일로 가장 적절한 것을 고르시오.", ["녹화 시작하기","마이크 점검하기","자료 업로드하기","온라인 링크 공유하기","카메라 앵글 점검하기"], ""),
6: ("대화를 듣고, 여자가 지불할 금액을 고르시오.", ["$25","$30","$45","$50","$55"], ""),
7: ("대화를 듣고, 남자가 도서관에서 책을 빌리지 못한 이유를 고르시오.", ["도서관에 늦게 도착해서","다른 학생이 이미 대출해서","학생증을 가져가지 않아서","제때 반납하지 않은 책이 있어서","도서관 네트워크 시스템에 문제가 있어서"], ""),
8: ("대화를 듣고, Race Against Hunger 행사에 관해 언급되지 않은 것을 고르시오.", ["목적","기간","상품","참가비","신청 방법"], ""),
9: ("AI Coding Afterschool Program에 관한 다음 내용을 듣고, 일치하지 않는 것을 고르시오.", ["1학년 학생을 대상으로 한다.","3시간 동안 진행된다.","AI 코딩 실습을 포함한다.","참가 학생은 자신의 컴퓨터를 가져와야 한다.","프로그램을 완료한 학생은 선물을 받는다."], ""),
10: ("다음 표를 보면서 대화를 듣고, 여자가 예약할 수업을 고르시오.", [],
     "<table><tr><th></th><th>Class</th><th>Level</th><th>Class Size</th><th>Price</th></tr>"
     "<tr><td>①</td><td>Cake Baking</td><td>Beginner</td><td>6 people</td><td>$30</td></tr>"
     "<tr><td>②</td><td>Cake Baking</td><td>Intermediate</td><td>4 people</td><td>$40</td></tr>"
     "<tr><td>③</td><td>Cookie Baking</td><td>Beginner</td><td>10 people</td><td>$30</td></tr>"
     "<tr><td>④</td><td>Cookie Baking</td><td>Advanced</td><td>7 people</td><td>$50</td></tr>"
     "<tr><td>⑤</td><td>Soap Making</td><td>Intermediate</td><td>5 people</td><td>$30</td></tr></table>"),
11: ("대화를 듣고, 여자의 마지막 말에 대한 남자의 응답으로 가장 적절한 것을 고르시오.", ["I’m sorry. I already bought a bike.","Sure. Let’s go to the park together.","You’re right. It’s not so hard to fix.","That’s too bad. Try to fix it, though.","No thanks. I heard it’ll rain tomorrow."], ""),
12: ("대화를 듣고, 남자의 마지막 말에 대한 여자의 응답으로 가장 적절한 것을 고르시오.", ["Don’t worry. Let’s meet and go over the rules together.","That’s nice. I think I understand the rules much better now.","Actually, yes. That’s the main reason I won the competition.","You’re welcome. I’ll ask our teammates to meet after school.","I agree with you. I also think the new rules are easy to follow."], ""),
13: ("대화를 듣고, 여자의 마지막 말에 대한 남자의 응답으로 가장 적절한 것을 고르시오.", ["Okay. I hope she understands our situation.","Well done. He will be ready to start the project today.","Don’t worry. We finished the project last week already.","Right. Let’s email her about the rescheduled project date.","Great. It’ll be easy to run the project with just the two of us."], ""),
14: ("대화를 듣고, 남자의 마지막 말에 대한 여자의 응답으로 가장 적절한 것을 고르시오.", ["Many visitors usually ask about the animals’ backgrounds.","The event starts at 10 a.m., so please come by then.","Some animals get nervous when many people gather.","Please take photos of the visitors with the animals.","I’m planning to finish uploading the photos tonight."], ""),
15: ("다음 상황 설명을 듣고, Emily가 Lucas에게 할 말로 가장 적절한 것을 고르시오.", ["I’m so sorry to hear that your bag is missing.","I appreciate your help in getting my bag back.","I’m afraid that I can’t help you find your bag.","Thank you for helping me buy a new bag.","I’m so glad you finally found your bag."], ""),
16: ("[16~17] 남자가 하는 말의 주제로 가장 적절한 것은?", ["meal patterns across different times of the day","various methods for preparing a quick breakfast","effective diet strategies aimed at health recovery","food choices recommended before morning exercise","practical tips for storing food items for busy people"], ""),
17: ("언급된 음식이 아닌 것은?", ["banana","yogurt","honey","egg","nut"], ""),
18: ("다음 글의 목적으로 가장 적절한 것은?", ["탁구 대회 운영을 위한 물품 기부를 요청하려고","탁구 센터 재개장 일정 연기를 알리려고","탁구 센터 이전 소식을 안내하려고","탁구 강습 프로그램을 홍보하려고","탁구 강습비 인상을 공지하려고"], ""),
19: ("다음 글에 드러난 Cassie의 심경 변화로 가장 적절한 것은?", ["excited → scared","amazed → envious","relaxed → annoyed","proud → embarrassed","confident → disappointed"], ""),
20: ("다음 글에서 필자가 주장하는 바로 가장 적절한 것은?", ["청중에게서 신뢰감을 얻기 위해 화자의 전문성을 강조해야 한다.","청중에게 영향을 주려면 화자 자신의 이야기로 유대감을 형성해야 한다.","논리적인 타당성을 확보하기 위해 객관적인 통계 자료를 제시해야 한다.","강연의 일관성을 유지하려면 화자의 사적인 감정 표현을 자제해야 한다.","청중을 효과적으로 설득하기 위해 정보를 최대한 상세히 설명해야 한다."], ""),
21: ("밑줄 친 steal the shade from our descendants가 다음 글에서 의미하는 바로 가장 적절한 것은?", ["ignore the benefits passed down from our fathers","remove environmental problems our generation faces","blame our children for their lack of responsibilities","take care of resources to give to the future generation","take from future generations what they deserve to have"], ""),
22: ("다음 글의 요지로 가장 적절한 것은?", ["뇌의 적응력은 나이가 들수록 급격히 저하된다.","어릴 때 형성된 식습관이 평생의 건강을 좌우한다.","개인의 식습관에는 유전적인 영향이 크게 작용한다.","다양한 음식의 섭취가 뇌의 구조적 발달을 촉진한다.","식성은 반복된 경험과 변화 의지를 통해 바꿀 수 있다."], ""),
23: ("다음 글의 주제로 가장 적절한 것은?", ["negative effects of social influence on teenagers","various factors that influence group decision-making","changes in the tendency to follow peers across ages","differences between individual choices and group decisions","ways to overcome peer pressure in the early teenage years"], ""),
24: ("다음 글의 제목으로 가장 적절한 것은?", ["Stop Thinking and Just Go to the Gym Now!","Avoid Listening to Music While You Work Out","Why Smart Businesses Focus on Healthcare Service","The Key to Success in Life: Give Up Everyday Hobbies","Pairing Pleasure with Effort: Guiding People to New Behavior"], ""),
25: ("다음 도표의 내용과 일치하지 않는 것은?", [], "<p class='small'>도표: 재택근무의 주요 이점 (2023년 세계 노동자 2만여 명 설문, 1인당 최대 3개 응답). 선택지 ①~⑤는 도표를 설명하는 지문 속 다섯 문장입니다.</p>"),
26: ("Gary Graffman에 관한 다음 글의 내용과 일치하지 않는 것은?", ["세 살에 피아노 연주를 시작했다.","1949년에 Leventritt Award를 수상했다.","오른손 손가락을 제어할 수 없게 되어 피아노 연주를 포기했다.","1980년에 Curtis Institute of Music으로 돌아갔다.","Lang Lang을 포함한 많은 뛰어난 젊은 음악가들을 가르쳤다."], ""),
27: ("Green Parking Pass에 관한 다음 안내문의 내용과 일치하지 않는 것은?", ["시의 모든 공영 주차장에서 사용할 수 있다.","Basic 타입은 오전 9시부터 오후 6시까지 이용 가능하다.","Premium 타입의 가격은 120달러이다.","시 공영 주차장 사무소에서는 구매할 수 없다.","한 사람당 한 개만 구매할 수 있다."], ""),
28: ("One Week Online Film Camp에 관한 다음 안내문의 내용과 일치하는 것은?", ["13세부터 참가할 수 있다.","주말에는 오후 5시에 시작한다.","요금은 1인당 100달러이다.","참가자는 10분 길이의 영화를 완성할 것이다.","참가 신청을 하려면 이메일을 보내야 한다."], ""),
29: ("다음 글의 밑줄 친 부분 중, 어법상 틀린 것은?", [], "<p>밑줄 친 부분: ① accurate ② helps ③ designed ④ where ⑤ that</p>"),
30: ("다음 글의 밑줄 친 부분 중, 문맥상 낱말의 쓰임이 적절하지 않은 것은?", [], "<p>밑줄 친 낱말: ① long ② consumes ③ same ④ more ⑤ accomplished</p>"),
31: ("[31~34] 다음 빈칸에 들어갈 말로 가장 적절한 것을 고르시오.", ["Revision","Invitation","Collection","Possession","Cooperation"], ""),
32: ("다음 빈칸에 들어갈 말로 가장 적절한 것을 고르시오.", ["adopting the teacher mindset","using leisure time effectively","activating background knowledge","supporting the emotional stability","reducing the amount of studying time"], ""),
33: ("다음 빈칸에 들어갈 말로 가장 적절한 것을 고르시오.", ["adding more complex symbols to describe the quality of goods","separating the number from the object they were counting","representing the physical shape of each object accurately","connecting the count of an object with its market value","applying the use of numbers to only precious items"], ""),
34: ("다음 빈칸에 들어갈 말로 가장 적절한 것을 고르시오.", ["conforming to the rules and conventions of the ingroup","following outgroup behavior which is socially appropriate","avoiding behaviors demonstrated by the ingroup on purpose","pursuing the most efficient strategy for completing the task","maintaining an individual identity rather than a group identity"], ""),
35: ("다음 글에서 전체 흐름과 관계 없는 문장은?", [], "<p class='small'>①~⑤는 지문 속 문장 번호입니다.</p>"),
36: ("[36~37] 주어진 글 다음에 이어질 글의 순서로 가장 적절한 것을 고르시오.", ["(A) - (C) - (B)","(B) - (A) - (C)","(B) - (C) - (A)","(C) - (A) - (B)","(C) - (B) - (A)"], ""),
37: ("주어진 글 다음에 이어질 글의 순서로 가장 적절한 것을 고르시오.", ["(A) - (C) - (B)","(B) - (A) - (C)","(B) - (C) - (A)","(C) - (A) - (B)","(C) - (B) - (A)"], ""),
38: ("[38~39] 글의 흐름으로 보아, 주어진 문장이 들어가기에 가장 적절한 곳을 고르시오.", [], "GIVEN:Thus, what we call major progress in science is not a movement from a less to a more accurate paradigm."),
39: ("글의 흐름으로 보아, 주어진 문장이 들어가기에 가장 적절한 곳을 고르시오.", [], "GIVEN:Yet a few hours later, after the sun has warmed the greenhouses above freezing, the second visit presents a miraculous contrast."),
40: ("다음 글의 내용을 한 문장으로 요약하려 한다. 빈칸 (A), (B)에 들어갈 말로 가장 적절한 것은?", [],
     "<table><tr><th></th><th>(A)</th><th>(B)</th></tr><tr><td>①</td><td>supportive</td><td>mild</td></tr><tr><td>②</td><td>supportive</td><td>strict</td></tr><tr><td>③</td><td>educational</td><td>strict</td></tr><tr><td>④</td><td>competing</td><td>mild</td></tr><tr><td>⑤</td><td>competing</td><td>public</td></tr></table>"),
41: ("[41~42] 윗글의 제목으로 가장 적절한 것은?", ["Patience Can Never Be an Answer","Focus on the Work That Truly Counts","Patience: Not a Weakness, but a Power","The Hidden Costs of Waiting Too Long","Being Patient: a Key to Long-term Relationship"], ""),
42: ("밑줄 친 (a)~(e) 중에서 문맥상 낱말의 쓰임이 적절하지 않은 것은?", [], "<p>밑줄 친 낱말: (a) passive (b) achievements (c) lowly (d) shifts (e) feed</p>"),
43: ("[43~45] 주어진 글 (A)에 이어질 내용을 순서에 맞게 배열한 것으로 가장 적절한 것은?", ["(B) - (D) - (C)","(C) - (B) - (D)","(C) - (D) - (B)","(D) - (B) - (C)","(D) - (C) - (B)"], ""),
44: ("밑줄 친 (a)~(e) 중에서 가리키는 대상이 나머지 넷과 다른 것은?", ["(a)","(b)","(c)","(d)","(e)"], ""),
45: ("윗글에 관한 내용으로 적절하지 않은 것은?", ["현자는 소박한 삶을 살았기에 동전이 필요하지 않았다.","왕은 현자가 한 행동에 당황스러웠고 약간 불쾌함을 느꼈다.","현자는 전쟁을 마치고 돌아오는 왕을 궁전 근처에서 보았다.","왕은 현자에게 다가가 축복을 부탁했다.","왕은 침략을 취소했고 자신이 가진 것을 소중히 여기기로 했다."], ""),
}

L = {
1:("밴드 리더가 축제 공연에서 듣고 싶은 곡을 종이에 적어 음악실 앞 요청함에 넣어 달라고 부탁합니다.","'축제'와 '공연'이 반복되지만 일정 변경(①)이나 신입 부원 모집(②) 이야기는 없습니다. 요청하는 내용이 곧 목적입니다."),
2:("여자는 운동 직후 스트레칭을 거르면 근육이 굳어 아프다며, 스트레칭이 통증을 줄여 준다고 말합니다.","남자가 '피곤해서 쉬었다'고 한 말 때문에 ①번(휴식)이 그럴듯하지만, 여자의 의견은 스트레칭입니다."),
3:("고등학교 입학 후 먼저 인사를 건네는 것이 새로운 관계를 만드는 계기가 된다는 내용입니다.","'인사에 적절히 반응하라'는 ⑤번은 먼저 인사하라는 핵심과 방향이 다릅니다."),
4:("대화에 나온 순서대로 현수막, 의자 위 모자, 캔 줍기, 줄무늬 셔츠, 장대 옆 축구공 세 개를 확인합니다.","그림 문제는 수량과 무늬가 단골 함정입니다. 축구공 개수를 그림과 꼭 비교하세요."),
5:("링크 공유, 자료 업로드, 카메라 앵글, 마이크는 모두 끝났고, 마지막에 '녹화를 아직 시작하지 않았다'며 곧 시작하겠다고 합니다.","이미 한 일과 앞으로 할 일을 구분하는 문제입니다. 할 일은 대화 끝에 나옵니다."),
6:("잠옷 $20 × 2벌 = $40, 양말 $5 × 2켤레 = $10, 합계 $50에서 쿠폰으로 10% 할인 → $45.","할인 전 금액 $50(④)이 대표 함정입니다."),
7:("책은 서가에 있었고 학생증도 있었으며 연체도 없었습니다. 도서관 네트워크 시스템 문제로 아무도 대출할 수 없었다고 합니다.","'다른 학생이 빌렸니?', '학생증 잊었니?'처럼 여자가 묻는 것이 모두 오답 선택지입니다."),
8:("목적(다음 세대를 위한 음식의 중요성), 기간(4월 11~29일), 상품(물병), 신청 방법(QR 코드)은 나오지만 참가비는 나오지 않습니다.","'언급되지 않은 것'은 들으면서 하나씩 지워 가는 것이 가장 정확합니다."),
9:("컴퓨터는 제공되므로 학생은 자신의 컴퓨터를 가져올 필요가 없다고 했습니다.","대상(1학년), 시간(3시간), 구성(AI 코딩 실습), 선물은 모두 일치합니다."),
10:("베이킹 수업만(⑤ 제외) → 상급 제외(④ 제외) → 8명 미만(③ 제외) → 둘 중 더 비싼 것 → ② Cake Baking Intermediate $40.","마지막 조건이 '더 비싼 것'이라는 점이 핵심입니다. 싼 것을 고르는 습관을 버리세요."),
11:("자전거를 고쳤으니 오후에 함께 타러 가자는 제안에 '좋아, 공원에 같이 가자'는 ②번이 자연스럽습니다.","제안에는 수락이나 거절로 답합니다."),
12:("새 규칙이 헷갈려 실수할까 걱정된다는 말에 '걱정 마, 만나서 같이 규칙을 살펴보자'는 ①번이 맞습니다.","걱정을 말하는 상대에게는 위로와 해결책을 주는 응답이 정답인 경우가 많습니다."),
13:("Jefferson 선생님께 프로젝트를 다음 주에 시작해도 되는지 직접 찾아가 여쭙기로 하자, 선생님이 상황을 이해해 주시길 바란다는 ①번이 이어집니다.","④번은 '이메일'을 말하지만 이미 직접 방문하기로 정했습니다."),
14:("행사 사진을 찍어 주겠다며 몇 시까지 가면 되는지 묻자, 10시에 시작하니 그때까지 오라는 ②번이 맞습니다.","의문사 What time에 시간으로 답하는 선택지를 찾으세요."),
15:("Lucas가 가방을 찾아 분실물 센터에 맡겨 준 덕분에 되찾았으므로, 고마움을 전하는 ②번이 맞습니다.","⑤번은 상대가 가방을 찾은 것처럼 말해 주어가 뒤바뀌었습니다."),
16:("아침 운동 전에 먹으면 좋은 음식(바나나, 요구르트, 달걀, 견과류)을 소개합니다.","'아침 식사 준비 방법'(②)은 소재만 비슷한 오답입니다."),
17:("바나나, 요구르트, 달걀, 견과류는 언급되었고 꿀은 나오지 않습니다.","16~17번은 두 번 들려주니 두 번째에 목록을 확인하세요."),
}

R = {
18:"탁구 센터 관리자가 보수 공사 중 전기 문제가 발견되어 재개장을 4월 1일에서 5월 1일로 '연기'한다고 알리는 글입니다. regret to inform you that the center’s reopening must be delayed가 결정적 문장입니다.",
19:"처음 간 축제에서 불빛과 음악에 신나서 뛰던 Cassie가, 괴물처럼 큰 퍼레이드 풍선을 보고 겁에 질려 엄마 뒤에 숨습니다. jump with joy → beat fast from fear의 흐름이므로 excited → scared입니다.",
20:"청중을 움직이는 가장 좋은 방법은 개인적인 이야기나 일화로 마음을 여는 것이며, 사람들은 주장이 아니라 그 주장을 하는 '사람'과 유대감을 형성한다는 주장입니다.",
21:"조상이 심은 정원을 누리면서 후손의 그늘을 훔쳐서는 안 된다는 비유입니다. '그늘을 훔친다'는 것은 미래 세대가 누려야 할 것을 지금 빼앗는다는 뜻이므로 ⑤번이 정답입니다. ④번은 반대로 '돌봐야 한다'는 긍정 행동이라 의미가 뒤집혔습니다.",
22:"식성은 어릴 때 굳어지는 것 같지만 신경 가소성 덕분에 평생 바뀔 수 있고, 반복된 경험과 변화하려는 의지가 핵심이라는 요지입니다. 마지막 문장 Repeated exposure — and a willingness to change — is the key가 근거입니다.",
23:"또래에 동조하려는 경향은 14세 무렵 정점에 이르고 16~17세에는 줄어든다는 연구 결과입니다. 주제는 '나이에 따른 또래 순응 경향의 변화'입니다.",
24:"즐거운 습관(오디오북 듣기)과 하기 싫은 습관(운동)을 묶는 '유혹 묶기'로 사람들의 행동을 바꾼 연구입니다. 제목은 ⑤ Pairing Pleasure with Effort입니다.",
25:"도표 문제는 선택지 문장마다 수치를 직접 대조해야 합니다. '개인적인 조용한 시간'이 '가족·친구와 더 많은 시간'보다 낮다는 ④번 문장이 도표와 일치하지 않습니다.",
26:"Graffman은 오른손 손가락을 제어할 수 없게 되었지만 피아노를 '결코 포기하지 않았고', 왼손을 위한 작품에 집중했습니다. 따라서 ③번이 틀립니다.",
27:"주차권은 온라인 '또는 시 공영 주차장 사무소'에서 구매할 수 있으므로, 사무소에서 구매할 수 없다는 ④번이 일치하지 않습니다.",
28:"14~17세 대상(①×), 주말 오후 1시 시작(②×), 1인당 200달러(③×), 5분보다 짧은 영화(④×), 이메일로 신청(⑤○). 정답은 ⑤번입니다.",
29:"②번 helps의 주어는 The files, folders, and icons로 복수입니다. 사이에 낀 you see displayed on a computer screen은 주어를 꾸미는 말일 뿐이므로 help가 맞습니다. (helps → help)",
30:"개발 도상국에서 걷기는 피할 수 없는 부담인 반면, 북미와 서유럽에서는 걷기를 효율적이고 건강한 것으로 봅니다. however로 대조되므로 태도가 '같다(same)'가 아니라 '정반대(opposite)'여야 합니다.",
31:"물건이 너무 많으면 아이들이 압도되어 선택을 못 한다는 글입니다. 빈칸은 '모두가 가진 것을 보고 사용하게 돕는 것'이므로, 물건을 줄이고 다시 정리하는 ① Revision(수정)이 정답입니다. 바로 뒤 문장의 Streamlining(간소화)이 같은 뜻을 받습니다.",
32:"학생들은 익숙함을 진짜 실력으로 착각하는데, 남에게 가르치듯 공부하면 그 착각이 깨진다는 글입니다. 빈칸은 친숙함을 숙달로 바꾸는 주어이므로 ① adopting the teacher mindset(가르치는 사람의 사고방식을 갖는 것)입니다.",
33:"In other words 뒤에 '물고기 기호 옆에 숫자 5를 따로 썼다'는 설명이 나오고, 이어서 숫자를 그대로 두고 대상 기호만 바꿨다고 합니다. 따라서 첫 지적 도약은 ② 셈하는 대상에서 숫자를 분리한 것입니다.",
34:"아이들은 싫어하는 내집단 구성원이라도 그들의 행동을 더 따라 했고, 이는 가장 효율적인 방법을 배우려는 것이 아니라는 내용입니다. 빈칸은 in other words로 '적절한 방식'을 풀어 쓴 것이므로 ① 내집단의 규칙과 관습을 따르는 것입니다. ④번은 본문이 명시적으로 부정한 '효율'을 말합니다.",
35:"지방 세포 수와 설정점이 식욕 신호를 결정한다는 '설정점 이론' 설명입니다. ④번은 지방 세포가 질병 치료에 도움이 될 수 있다는 다른 이야기라 흐름과 무관합니다.",
36:"주어진 글(less is more는 처음엔 단순한 의미) → (B) 그 문구의 출처와 오늘날의 쓰임 → (C) But, 그 사고방식이 관습을 없앤다, 예: 거대한 라디오 → (A) 시간이 지나며 버튼이 제거되어 휴대전화로 발전. (A)의 their buttons가 (C)의 라디오를 가리킵니다.",
37:"주어진 글(플라스틱 이전엔 지속 가능했다) → (C) However, 플라스틱이 발명되어 어디에나 퍼짐, 아메리칸 드림의 상징 → (B) This dream came with a price, 환경 운동의 씨앗 → (A) However, 업계가 이런 우려에 맞서 재활용 캠페인. (B)의 This dream이 (C)의 American dream을 받습니다.",
38:"④ 앞까지는 '과학 연구와 측정은 특정 패러다임 안에서만 의미가 있다'는 설명이고, ④ 뒤는 Rather로 시작해 '하나의 보는 방식에서 다른 방식으로의 수평 이동'이라고 말합니다. Rather 앞에는 '~이 아니다'라는 부정이 와야 하므로, 주어진 문장(덜 정확한 것에서 더 정확한 것으로의 이동이 아니다)이 ④에 들어갑니다.",
39:"③ 앞은 새벽 방문 때 얼어붙은 황량한 잎, ③ 뒤는 생기 넘치는 잎이 줄지어 있는 모습입니다. 그 사이에 Yet a few hours later로 '두 번째 방문은 기적적인 대조를 보여 준다'는 전환이 필요하므로 ③이 정답입니다.",
40:"아이들이 혼자 다닐 수 있는 안전한 길과 공간이 없어서 부모의 시간과 돈이 더 든다며, '가볍게 감독받는 아이들이 자유롭게 다닐 수 있는 환경'을 만들어야 한다는 글입니다. (A) supportive(지원적인), (B) mild(가벼운)입니다.",
41:"인내심은 수동적이고 힘없는 사람의 미덕으로 여겨졌지만, 서두르는 사회에서는 오히려 힘의 한 형태가 된다는 글입니다. 제목은 ③ Patience: Not a Weakness, but a Power입니다.",
42:"서두름에 맞춰진 세상에서 힘이 되는 것은 서두르고 싶은 충동을 '억누르는' 능력입니다. (e) feed(충족시키다)는 resist(억제하다)로 바꿔야 합니다.",
43:"(A) 현자가 동전을 주울 사람을 찾지 못함 → (C) 다음 날 전쟁을 준비하는 왕에게 동전을 건넴 → (B) 왕이 당황해 이유를 물음 → (D) 더 많은 것을 원하는 왕에게 필요하다고 답하고, 왕이 침략을 취소. 정답 (C)-(B)-(D)입니다.",
44:"(a)(b)(c)(d)는 모두 현자를 가리키고, (e) his plans는 계획을 바꾼 왕을 가리킵니다.",
45:"현자와 제자는 궁전 근처에서 전쟁을 '준비하고 있는' 왕을 보았습니다. 전쟁을 마치고 돌아오는 왕이 아니므로 ③번이 틀립니다.",
}

VOCAB = {
18:[("upcoming","다가오는"),("unexpected","예상치 못한"),("electrical","전기의"),("regret to","~하게 되어 유감이다"),("delay","연기하다"),("originally","원래"),("ensure","보장하다"),("patience","인내")],
19:[("carnival","축제"),("imagine","상상하다"),("twinkling","반짝이는"),("trick","기술, 묘기"),("suddenly","갑자기"),("fear","공포")],
20:[("stir","동요시키다"),("anecdote","일화"),("biographical","전기(傳記)적인"),("tried-and-tested","입증된"),("groundwork","기틀"),("persuade","설득하다"),("harsh","냉혹한"),("flaw","결점")],
21:[("unprecedented","전례 없는"),("species","종"),("embodied","육체를 가진"),("far-reaching","광범위한"),("ancestor","조상"),("stewardship","관리"),("descendant","후손")],
22:[("inborn","타고난"),("preference","선호도"),("neuroplasticity","신경 가소성"),("adaptability","적응력"),("adventurous","모험적인"),("readjust","재조정하다"),("processed","가공된"),("willingness","의지")],
23:[("conformity","순응"),("fascinating","흥미로운"),("peak","정점"),("tendency","경향"),("stand up for","~을 옹호하다"),("demonstrate","입증하다"),("peer","또래"),("resilient","회복 탄력적인")],
24:[("essential","필수적인"),("attach","결합하다"),("temptation","유혹"),("bundling","묶기"),("hostage","볼모"),("put off","미루다"),("opt to","~하는 것을 선택하다")],
25:[("benefit","이점"),("survey","설문 조사"),("commute","통근"),("respondent","응답자"),("cite","언급하다"),("gap","격차")],
26:[("foundation","기초"),("give up","포기하다"),("reconsider","재고하다"),("convention","관습"),("faculty","교수진"),("outstanding","뛰어난"),("commitment","헌신")],
27:[("convenient","편리한"),("public","공영의"),("available","이용 가능한"),("reserved","지정된"),("purchase","구매하다")],
28:[("direct","연출하다"),("shoot","촬영하다"),("edit","편집하다"),("interactive","쌍방향의"),("instruction","강연, 지도"),("screen","상영하다")],
29:[("conceptual","개념적인"),("simplified","단순화된"),("display","표시하다"),("conceptualization","개념화"),("depiction","묘사"),("coherent","일관된"),("consist of","~로 구성되다")],
30:[("principal","주요한"),("constraint","제약"),("transit","운송"),("expend","소비하다"),("spare","내어 주다"),("unavoidable","피할 수 없는"),("burden","부담"),("simulate","모방하다")],
31:[("anxiety","불안감"),("house","보관하다"),("overwhelmed","압도된"),("closet","옷장"),("streamline","간소화하다"),("indecision","망설임")],
32:[("familiarity","친숙함"),("mastery","숙달"),("illusion","착각"),("competence","능력"),("cognitive","인지의"),("passive","수동적인"),("overestimate","과대평가하다")],
33:[("official","관리"),("clay tablet","점토판"),("intellectual","지적인"),("leap","도약"),("numeral","숫자"),("emancipated","해방된"),("take ~ for granted","~을 당연하게 여기다")],
34:[("ingroup","내집단"),("distinguish","식별하다"),("antisocial","반사회적인"),("prosocial","친사회적인"),("over-imitation","과잉 모방"),("convention","관습")],
35:[("stable","안정적인"),("quantity","수량"),("trigger","방아쇠, 계기"),("release","분비하다"),("chemical","화학 물질"),("desire","욕구")],
36:[("catchphrase","유명 문구"),("tangled","뒤엉킨"),("extinguish","소멸시키다"),("massive","거대한"),("eventually","결국"),("multilayered","다층화된")],
37:[("sustainably","지속 가능하게"),("launch","시작하다"),("corporation","기업"),("adoption","채택"),("prosperity","번영"),("symbolize","상징하다")],
38:[("proposition","명제"),("embed","깊이 박아 넣다"),("interrelated","상호 연관된"),("methodological","방법론적인"),("undertake","수행하다"),("exacting","엄밀한"),("horizontal","수평적인")],
39:[("striking","인상적인"),("frost-coated","서리가 내려앉은"),("bleak","황량한"),("convince","납득시키다"),("vigorous","생기가 넘치는"),("miraculous","기적적인")],
40:[("independence","독립심"),("resilience","회복 탄력성"),("suburb","교외 지역"),("structural","구조적인"),("tolerance","관용"),("supervised","감독받는")],
41:[("prospect","예상"),("disturbingly","불안하게 할 정도로"),("virtue","미덕"),("self-effacing","자기를 내세우지 않는"),("accommodate","순응시키다"),("resign","단념하다"),("derive","얻다"),("fulfillment","성취")],
43:[("sage","현자"),("disciple","제자"),("prosperous","번영한"),("genuine","진정한"),("content","만족한"),("conquer","정복하다"),("call off","취소하다"),("appreciate","소중히 여기다")],
}

TREND = ("<b>듣기</b>는 축제, 운동, 도서관, 방과후 프로그램 등 고1 신입생에게 익숙한 학교생활 소재가 중심이었고 6·12·14번이 3점이었습니다. "
         "<b>독해 앞부분</b>은 21번 함축 의미(후손의 그늘을 훔치다)와 24번 제목이 3점으로 출제되었습니다. "
         "<b>빈칸 31~34번</b>은 33번(숫자의 분리)과 34번(내집단 모방)이 3점이었고, <b>간접 쓰기</b>는 38번 삽입과 42번 장문 어휘가 3점이었습니다. "
         "고1 첫 학평답게 전체 난도는 평이했지만, 3점 문항에서 점수 차이가 났습니다.")
BLANK_TIP = "고1 3월 빈칸은 'In other words'나 바로 뒤 문장이 빈칸을 다시 풀어 주는 경우가 많았습니다. 빈칸 앞뒤 한 문장씩을 꼭 확인하세요."

THUMB_ANS = [[21,4,True],[24,4,True],[29,1,True],[31,0,False],[33,1,True],[34,0,True],[37,4,False],[38,3,True],[42,4,True],[43,1,False]]
THUMB_LISTEN = [[1,3,False],[2,3,False],[5,0,False],[6,2,True],[7,4,False],[9,3,False],[10,1,False],[12,0,True],[14,1,True],[15,1,False]]
THUMB_BLANK = [["31 Streamlining이 단서","①"],["32 가르치는 사람의 시각","①"],["33 In other words 뒤 설명","②"],["34 효율 ≠ 목적","①"],["35 지방 세포와 질병 치료","④"]]
THUMB_ORDER = [["36·37 순서","③ · ⑤"],["38·39 삽입","④ · ③"],["40 요약","①"],["41·42 장문","③ · ⑤"],["43~45 장문","② · ⑤ · ③"]]

VOCAB_KEY = [("regret to", "~하게 되어 유감이다", "18번 목적을 결정하는 표현"),
             ("descendant", "후손", "21번 함축 의미 '후손의 그늘'을 푸는 열쇠"),
             ("neuroplasticity", "신경 가소성", "22번 요지 — 식성은 평생 바뀔 수 있다"),
             ("streamline", "간소화하다", "31번 빈칸 Revision을 다시 풀어 준 단어"),
             ("convention", "관습", "34번 빈칸 정답 표현 rules and conventions"),
             ("call off", "취소하다", "45번 왕이 침략을 취소하는 결말")]
