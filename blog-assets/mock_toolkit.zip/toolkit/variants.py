import sys, re, json
sys.argv = [sys.argv[0], sys.argv[1]] + sys.argv[2:]
import build as B
links = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
C = B.C
CDN = f"https://cdn.jsdelivr.net/gh/KKHLAND/edu-hub@blog-assets/blog-assets/{C}/"
D = f"/home/claude/edu-hub/blog-assets/{C}/"
meta = {}
for k, h in B.build(links).items():
    style = re.search(r'<style>.*?</style>', h, re.S).group(0)
    body = re.search(r'<div class="mq">.*</div>', h, re.S).group(0)
    tags = re.search(r'<p class="small">(?:태그|라벨): (.*?)</p>', body).group(1)
    body = re.sub(r'\n?<p class="small">(?:태그|라벨): .*?</p>', '', body)
    body = re.sub(r'src="(listen_[^"]+\.mp3)"', lambda m: f'src="{CDN}{m.group(1)}"', body)
    img = re.search(r'<p><img src="([^"]+)"[^>]*></p>', body)
    tist = body.replace(img.group(0), '<!--IMG-->')
    blog = body.replace(f'src="{img.group(1)}"', f'src="{CDN}{img.group(1)}"')
    open(f"{D}post_{k}_t.html", 'w').write(style + tist)
    open(f"{D}post_{k}_b.html", 'w').write(style + blog)
    meta[k] = dict(title=B.TITLES[k], tags=[t.strip() for t in tags.split(',')], img=img.group(1))
json.dump(meta, open(f"{D}meta.json", 'w'), ensure_ascii=False, indent=1)
print(json.dumps(meta, ensure_ascii=False)[:800])
