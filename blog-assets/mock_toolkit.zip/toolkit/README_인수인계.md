# 모의고사 해설 블로그 — 작업 인수인계 (2026-11-14 갱신)

## 블로그
- 티스토리 '고등 영어 모의고사 해설' (koreaholic.tistory.com) → 시험마다 T1·T2·T3
  - 포스트 주소: **문자**로 변경함(11/14). 글 주소 = https://koreaholic.tistory.com/entry/<슬러그>
  - 카테고리 없음(아직 만들지 않음)
  - 발행 시 카카오 보안 확인(지도 글자 맞히기)이 뜸 → 선생님이 직접 입력해야 함
- 블로그스팟 '쌤의 영어 해설노트' (kkhnote.blogspot.com, Blogger ID 4162793713169921920) → 시험마다 B1·B2
  - 맞춤 퍼머링크: /2026/11/mock-<코드>-31-35.html, mock-<코드>-36-45.html (발행 월 기준)
  - 라벨은 글 편집 화면에서 저장이 안 됨 → 글 목록 '관리' → 라벨 아이콘으로 붙이기

## 시험 1회차 = 5편 (예약 시각: 오후 6시)
| 편 | 블로그 | 내용 |
|---|---|---|
| T1 | 티스토리 | EBSi 자료 받기 + 정답표 + 출제 경향 + 독해 18~30 |
| T2 | 티스토리 | 듣기 1~17 (핵심 단서·함정) + 유사 듣기 2문항(음성) |
| T3 | 티스토리 | 핵심 어휘 |
| B1 | 해설노트 | 빈칸·무관 31~35 |
| B2 | 해설노트 | 36~45 + 유사 독해 2문항 |
- 문항 카드: 발문 + [지문 자리(점선 상자)] + 선택지 + 접힌 '정답과 해설 보기'
- 지문 전문은 넣지 않음(원저작권). 점선 상자 안 안내 문장을 지우고 선생님이 지문을 붙여 넣으면 됨. 그대로 두어도 'EBSi 문제지에서 함께 보세요' 안내로 읽힘.

## 진행 현황
- 3월 고1: 예약 완료 — T1 11/16, B1 11/16, T2 11/17, B2 11/17, T3 11/18 (모두 18:00)
- 수능(11/19): 당일 저녁 빠른 정답·총평(양쪽, 문장 다르게) → 11/20 T1+B1 → 11/21 T2+B2
- 이후 일정: 3월 고2 11/22~24 · 3월 고3 11/25~27 · 5월 고3 11/28~30 · 6월 고1 12/1~3 · 6월 고2 12/4~6 · 6월 모평 고3 12/7~9 · 7월 고3 12/10~12 · 9월 고1 12/13~15 · 9월 고2 12/16~18 · 9월 모평 고3 12/19~21 · 10월 고1 12/22~24 · 10월 고2 12/25~27 · 10월 고3 12/28~30

## 파일 (toolkit)
- exams/<코드>.py — 시험 데이터 (META, ANS, PT3, Q, L, R, VOCAB, VOCAB_KEY, TREND, BLANK_TIP, THUMB_*). 형식은 m0324g1.py 참고
- exams/<코드>_similar.py — 유사 듣기(LISTEN)·유사 독해(READ) 창작 문항
- build.py <코드> — 5편 HTML 생성 (out/)
- variants.py <코드> '<링크 JSON>' — 블로그별 붙여넣기 본문(post_T1_t.html, post_B1_b.html …)과 meta.json을 edu-hub blog-assets/<코드>/ 에 생성
- thumbs.py <코드> — 대표 이미지 5장 (mock_thumb.py 사용, Playwright + Noto Sans CJK)
- tts.py <코드>_similar — 유사 듣기 mp3 (Kokoro TTS: kokoro-v1.0.onnx, voices-v1.0.bin / 남 am_michael, 여 af_heart, speed 0.92)
- suneung_quick.py data.json — 수능 당일 빠른 정답·총평 글 2편(sn_T0, sn_B0)
- tistory_prep.js — 티스토리 글쓰기 화면 자동 입력 도우미 설명

## 이미지·음성 호스팅
- GitHub KKHLAND/edu-hub 저장소의 **blog-assets 브랜치**(main 아님) / blog-assets/<코드>/
- 주소: https://cdn.jsdelivr.net/gh/KKHLAND/edu-hub@blog-assets/blog-assets/<코드>/<파일>
- 티스토리는 대표 이미지를 붙여넣기로 티스토리에 직접 업로드, 음성은 jsDelivr 주소 사용
- 블로그스팟은 이미지·음성 모두 jsDelivr 주소 사용

## 남은 확인 사항
- EBSi 시험별 정확한 링크 (현재 기출문제 첫 화면 링크 + 경로 안내)
- 티스토리 카테고리 만들기 여부
