import sys, importlib, numpy as np, soundfile as sf, subprocess
sys.path.insert(0, '/home/claude/mock3/exams')
from kokoro_onnx import Kokoro
mod = importlib.import_module(sys.argv[1])
k = Kokoro('/home/claude/tts/kokoro-v1.0.onnx', '/home/claude/tts/voices-v1.0.bin')
V = {'M': 'am_michael', 'W': 'af_heart'}
for it in mod.LISTEN:
    parts = []; sr = 24000
    for who, text in it['script']:
        s, sr = k.create(text, voice=V[who], speed=0.92, lang='en-us')
        parts += [s, np.zeros(int(sr * 0.55), dtype=s.dtype)]
    wav = f"/home/claude/mock3/out/listen_{it['id']}.wav"
    sf.write(wav, np.concatenate(parts), sr)
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-ac', '1', '-b:a', '64k', wav[:-4] + '.mp3'], check=True)
    print(it['id'], len(np.concatenate(parts)) / sr, 'sec')
