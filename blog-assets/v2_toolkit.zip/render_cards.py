import json, re, html, sys, asyncio
sys.path.insert(0, '/home/claude/mock3/exams'); sys.path.insert(0, '.')
import m0324g1 as M
from listen_ko import KO, VOC, RKO, RVOC
from playwright.async_api import async_playwright

Q = {int(k): v for k, v in json.load(open('qa.json')).items()}
N = '①②③④⑤'
scripts = open('scripts.txt').read().split('\n\n#####\n\n')
SC = {}
for s in scripts:
    m = re.match(r'(\d{1,2})\.', s)
    if m and int(m.group(1)) <= 15:
        SC[int(m.group(1))] = s.split('\n', 1)[1].strip()
    elif s.startswith('[16'):
        SC[16] = s.split('\n', 1)[1].strip()
SC[15] = SC[15].replace('16번부터 17번까지는 두 번 들려줍니다.', '').strip()

def md(lines):
    out, tbl = [], []
    def flush():
        if not tbl: return
        rows = [r for r in tbl if not re.match(r'^\|\s*:?-', r)]
        h = '<table>'
        for i, r in enumerate(rows):
            cells = [c.strip() for c in r.strip('|').split('|')]
            tag = 'th' if i == 0 else 'td'
            h += '<tr>' + ''.join(f'<{tag}>{html.escape(c)}</{tag}>' for c in cells) + '</tr>'
        out.append(h + '</table>'); tbl.clear()
    for ln in lines:
        ln = ln.replace('&amp;', '&')
        if ln.startswith('|'): tbl.append(ln); continue
        flush()
        if not ln.strip(): continue
        e = html.escape(ln)
        e = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', e)
        if re.match(r'^[①②③④⑤]', ln): out.append(f'<p class="ch">{e}</p>')
        elif ln.startswith('*') and not ln.startswith('**'): out.append(f'<p class="fn">{e}</p>')
        elif ln.startswith('- ') or ln.startswith('Note'): out.append(f'<p class="sm">{e}</p>')
        else: out.append(f'<p>{e}</p>')
    flush()
    return '\n'.join(out)

def script_html(s):
    out = []
    for ln in s.split('\n'):
        ln = ln.strip()
        if not ln: continue
        e = html.escape(ln)
        e = re.sub(r'^(M|W|Emily|Man|Woman):', r'<b>\1:</b>', e)
        out.append(f'<p class="sc">{e}</p>')
    return '\n'.join(out)

def ko_html(s):
    return '\n'.join(f'<p>{html.escape(l)}</p>' for l in s.split('\n') if l.strip())

def voc_html(v):
    return '<ul class="voc">' + ''.join(f'<li><span class="bx"></span>{html.escape(a)} - {html.escape(b)}</li>' for a, b in v) + '</ul>'

CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{width:1200px;background:#fff;font-family:'Noto Sans CJK KR','Noto Sans KR',sans-serif;color:#111}
.card{display:flex;padding:22px 20px 26px}
.L{width:66%;padding-right:26px;border-right:1.5px solid #eee}
.R{width:34%;padding-left:24px}
.num{font-size:28px;font-weight:700;margin-bottom:14px}
.stem{font-size:23px;margin-bottom:16px;line-height:1.5}
.L p{font-size:21px;line-height:1.75;text-align:justify;margin-bottom:6px}
.L p.ch{text-align:left;margin:4px 0;line-height:1.5}
.L p.fn{text-align:right;font-size:16px;margin:2px 0}
.L p.sm{font-size:16px;color:#333;text-align:center}
.L p.sc{font-size:18px;line-height:1.6;text-align:left;margin-bottom:4px}
.L .lab{display:inline-block;font-size:15px;font-weight:700;color:#1a73e8;border:1.5px solid #1a73e8;border-radius:4px;padding:1px 8px;margin:18px 0 10px}
.L hr{border:0;border-top:1.5px solid #eee;margin:16px 0}
table{border-collapse:collapse;margin:10px 0 14px;font-size:17px;width:100%}
th,td{border:1px solid #999;padding:5px 8px;text-align:center}
th{background:#f2f4f7}
.R h3{font-size:28px;font-weight:700;color:#333;margin:2px 0 14px}
.R p{font-size:14.5px;line-height:1.75;color:#333;text-align:justify;margin-bottom:4px}
.ans{font-size:25px;font-weight:700;color:#1a73e8;margin:20px 0 6px}
.R hr{border:0;border-top:1.5px solid #eee;margin:22px 0 18px}
.voc{list-style:none}
.voc li{font-size:17px;line-height:1.55;color:#333;display:flex;align-items:center}
.bx{display:inline-block;width:15px;height:15px;border:1.5px solid #777;margin-right:10px;flex:none}
.u{text-decoration:underline}
.chart{margin:8px 0 10px;padding:10px 6px 4px;border:1px solid #bbb}
.br{display:flex;align-items:center;margin:7px 0}
.bl{width:44%;font-size:15px;text-align:right;padding-right:10px;line-height:1.25}
.bt{width:56%;display:flex;align-items:center}
.bf{display:inline-block;height:20px;background:#7f8c9d}
.bv{font-size:14px;margin-left:6px}
.ax{display:flex;justify-content:space-between;margin-left:44%;font-size:12px;color:#555;border-top:1px solid #999;padding-top:3px}
"""

def card(num, left, right_ko, answers, voc):
    ans = ''.join(f'<div class="ans">{a}</div>' for a in answers)
    return f"""<div class="card"><div class="L"><div class="num">{num}</div>{left}</div>
<div class="R"><h3>해석</h3>{right_ko}{ans}<hr><h3>어휘 및 어구</h3>{voc_html(voc)}</div></div>"""

cards = {}
# listening 1..15
for n in range(1, 16):
    q = Q[n]
    body = [l for l in q['body'] if not re.match(r'^(Man|Woman|Emily):', l)]
    extra = '<p class="sm">※ 그림은 EBSi 문제지 4번에서 확인하세요.</p>' if n == 4 else ''
    left = f'<div class="stem">{html.escape(q["stem"])}</div>{extra}{md(body)}<span class="lab">듣기 대본</span>{script_html(SC[n])}'
    cards[f'L{n:02d}'] = card(n, left, ko_html(KO[n]), [f'정답: {N[M.ANS[n]-1]}'], VOC[n])
# 16~17
left = (f'<div class="stem">16. {html.escape(Q[16]["stem"])}</div>{md(Q[16]["body"])}'
        f'<div class="stem" style="margin-top:14px">17. {html.escape(Q[17]["stem"])}</div>{md([l for l in Q[17]["body"] if not l.startswith("이제")])}'
        f'<span class="lab">듣기 대본</span>{script_html(SC[16])}')
cards['L16'] = card('16~17', left, ko_html(KO[16]), [f'16번 정답: {N[M.ANS[16]-1]}', f'17번 정답: {N[M.ANS[17]-1]}'], VOC[16])
# reading 25 27 28
for n in (25, 27, 28):
    q = Q[n]
    left = f'<div class="stem">{html.escape(q["stem"])}</div>{md(q["body"])}'
    if n == 25:
        rows = [l for l in q['body'] if l.startswith('|') and not l.startswith('| Benefit') and not l.startswith('| :')]
        bars = '<div class="chart">'
        for r in rows:
            lab, v = [c.strip() for c in r.strip('|').split('|')]
            bars += (f'<div class="br"><span class="bl">{html.escape(lab)}</span><span class="bt">'
                     f'<span class="bf" style="width:{float(v)/70*100:.1f}%"></span><span class="bv">{v}</span></span></div>')
        bars += '<div class="ax"><span>0</span><span>10</span><span>20</span><span>30</span><span>40</span><span>50</span><span>60</span><span>70 (%)</span></div></div>'
        left = re.sub(r'<table>.*?</table>', bars, left, flags=re.S)
    cards[f'q{n}'] = card(n, left, ko_html(RKO[n]), [f"정답: {N[M.ANS[n]-1]}"], RVOC[n])
# 43~45
b = open('hwp/b.txt').read()
seg = b[b.index('[43 ~ 45]'):]
pas = seg[:seg.index('43. ')]
pas = re.sub(r'\((\w)\) \n(\w+)\n ', lambda m: f'({m.group(1)}) <span class="u">{m.group(2)}</span> ', pas)
plines = pas.split('\n')[1:]
def para(l):
    l = l.strip()
    if not l: return ''
    if l.startswith('*'): return f'<p class="fn">{l}</p>'
    return f'<p>{l}</p>'
left = ''.join(para(l) for l in plines)
qs = seg[seg.index('43. '):]
qs = qs[:qs.index('\n(A) 어느')] + '\n' + qs[qs.index('45. '):]
qlines = [l for l in qs.split('\n') if l.strip()]
qh = ''
for l in qlines:
    if re.match(r'^4[345]\.', l): qh += f'<div class="stem" style="margin:14px 0 6px">{html.escape(l)}</div>'
    else: qh += '<p class="ch">' + re.sub(r'\s*([①②③④⑤])', r'&nbsp;&nbsp;&nbsp;\1', html.escape(l.strip())).lstrip('&nbsp;') + '</p>'
ko = seg[seg.index('\n(A) 어느') + 1: seg.index('45. ')]
cards['q43-45'] = card('43~45', left + '<hr>' + qh, ko_html(ko),
                       [f'43번 정답: {N[M.ANS[43]-1]}', f'44번 정답: {N[M.ANS[44]-1]}', f'45번 정답: {N[M.ANS[45]-1]}'],
                       RVOC[43])

async def main():
    async with async_playwright() as p:
        br = await p.chromium.launch()
        pg = await br.new_page(viewport={'width': 1200, 'height': 800}, device_scale_factor=1)
        for k, c in cards.items():
            await pg.set_content(f'<html><head><meta charset="utf-8"><style>{CSS}</style></head><body>{c}</body></html>')
            await pg.wait_for_timeout(150)
            await pg.locator('.card').screenshot(path=f'crops/{k}.png')
            print(k)
        await br.close()
asyncio.run(main())
