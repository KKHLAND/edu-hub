import sys, json, importlib, subprocess
sys.path.insert(0, '/home/claude/mock3/exams')
X = importlib.import_module(sys.argv[1]); M = X.META; C = M['code']
S = f"{M['month']} {M['grade']}"
kick = f"{M['date']} 시행 · 전국연합학력평가"
G = {"brand": "쌤의 영어 해설노트", "css": ".top{background:#1e5b45}.right{border-color:#1e5b45;box-shadow:10px 10px 0 #1e5b45}.rh{border-color:#1e5b45}.kick{color:#2f7a5d}h1{color:#16382b}.right{height:auto;padding-bottom:30px}"}
nv = sum(len(v) for v in X.VOCAB.values())
words = [(w, m) for k in sorted(X.VOCAB) for w, m in X.VOCAB[k][:1]][:6]
specs = {
 f"mock_{C}_answer": dict(kind="answers", tag="정답·해설", kicker=kick, badge=S, head="고난도 문항 정답", title=f"{S} 영어<br><span class=\"hl\">정답·해설</span>", sub="정답표 1~45번 + 출제 경향\n독해 18~30번 문항별 풀이", foot="현직 고등학교 영어 교사의 문항별 해설", rows=X.THUMB_ANS),
 f"mock_{C}_listen": dict(kind="answers", tag="듣기 1~17번", kicker=kick, badge=S, head="듣기 주요 문항 정답", title=f"{S} 영어<br><span class=\"hl\">듣기 해설</span>", sub="문항별 핵심 단서와 함정\n유사 듣기 2문항 (음성 포함)", foot="현직 고등학교 영어 교사의 듣기 문항별 해설", rows=X.THUMB_LISTEN),
 f"mock_{C}_vocab": dict(kind="words", tag="어휘 정리", kicker=kick, range="18~45번", title=f"{S} 영어<br><span class=\"hl\">핵심 어휘 {nv}</span>", sub="독해 18~45번 문항별 정리\n지문 속에서 다시 보는 단어장", foot="현직 고등학교 영어 교사가 고른 시험 어휘", count=f"외 {nv-len(words)}개 · 본문에서", words=words),
 f"bs_{C}_blank": dict(G, kind="list", kicker=kick, tag="빈칸·무관한 문장", title=f"{S} 영어<br><span class=\"hl\">빈칸 31~35번</span>", sub="발문·선택지·정답·오답 분석\n3점 33·34번 함정까지", foot="현직 고등학교 영어 교사의 유형별 풀이", head="문항별 결정적 단서", head2="정답", items=X.THUMB_BLANK),
 f"bs_{C}_order": dict(G, kind="list", kicker=kick, tag="순서·삽입·장문", title=f"{S} 영어<br><span class=\"hl\">36~45번 + 유사</span>", sub="연결어 · 지시어 · 대비 구조\n유사 독해 문제 2개 포함", foot="현직 고등학교 영어 교사의 유형별 풀이", head="문항별 결정적 단서", head2="정답", items=X.THUMB_ORDER),
}
for name, sp in specs.items():
    p = f"/home/claude/mock3/out/{name}.json"; json.dump(sp, open(p, 'w'), ensure_ascii=False)
    subprocess.run(["python3", "/home/claude/mock3/mock_thumb.py", p, f"/home/claude/mock3/out/{name}.png"], check=True)
    print(name)
