# 모의고사 원스톱 해설 5편 생성기 (일반화 버전)
# 사용: python3 build.py m0324g1   → out/<code>_T1.html ... out/<code>_B2.html
import sys, html, importlib, re
sys.path.insert(0, '/home/claude/mock3/exams')
code = sys.argv[1]
X_ = importlib.import_module(code)
S_ = importlib.import_module(code + '_similar')
META, ANS, Q, L, R, VOCAB = X_.META, X_.ANS, X_.Q, X_.L, X_.R, X_.VOCAB
PT3 = getattr(X_, 'PT3', set())
LISTEN, READ = S_.LISTEN, S_.READ
OUT = '/home/claude/mock3/out/'
C = META['code']
N = "①②③④⑤"
EBSI = getattr(X_, 'EBSI', "https://www.ebsi.co.kr/ebs/xip/xipc/previousPaperList.ebs")
X = META['label']                       # 2026년 3월 고1
SHORT = f"{META['month']} {META['grade']}"  # 3월 고1
EXAM = META.get('exam', '전국연합학력평가')

TYPE = {1:"목적",2:"의견",3:"요지",4:"그림 불일치",5:"할 일",6:"금액",7:"이유",8:"언급되지 않은 것",9:"내용 불일치",
10:"도표",11:"짧은 응답",12:"짧은 응답",13:"긴 응답",14:"긴 응답",15:"상황 응답",16:"주제",17:"언급되지 않은 것",
18:"목적",19:"심경 변화",20:"주장",21:"함축 의미",22:"요지",23:"주제",24:"제목",25:"도표",26:"내용 불일치",
27:"안내문 불일치",28:"안내문 일치",29:"어법",30:"어휘",31:"빈칸",32:"빈칸",33:"빈칸",34:"빈칸",35:"무관한 문장",
36:"순서",37:"순서",38:"삽입",39:"삽입",40:"요약",41:"제목",42:"어휘",43:"순서",44:"지칭",45:"내용 불일치"}
TYPE.update(getattr(X_, 'TYPE', {}))
NAVY, GREEN = "#1f4e79", "#1e5b45"

def css(c):
    return f"""<style>
.mq{{font-family:'Noto Sans KR',sans-serif;max-width:760px;margin:0 auto;line-height:1.85;color:#222}}
.mq h2{{border-left:6px solid {c};padding-left:10px;margin:40px 0 14px;font-size:1.3em}}
.mq h3{{color:{c};margin:24px 0 6px}}
.mq .dl{{border:2px solid {c};border-radius:10px;padding:14px 18px;margin:18px 0;background:#fafcff}}
.mq .dl b{{color:{c}}} .mq .dl a{{color:{c};font-weight:700}}
.mq .card{{border:1px solid #d9dee6;border-radius:10px;padding:14px 18px;margin:16px 0;background:#fff}}
.mq .qh{{font-weight:700}} .mq .no{{display:inline-block;background:{c};color:#fff;border-radius:6px;padding:0 10px;margin-right:8px}}
.mq .ty{{display:inline-block;font-size:.8em;color:{c};border:1px solid {c};border-radius:20px;padding:0 9px;margin-left:6px;font-weight:500}}
.mq .pt{{color:#c0392b;font-size:.85em;margin-left:4px}}
.mq ol.ch{{list-style:none;padding-left:4px;margin:8px 0}} .mq ol.ch li{{margin:2px 0}}
.mq details{{background:#f6f8fb;border-radius:8px;padding:8px 14px;margin-top:8px}}
.mq summary{{cursor:pointer;font-weight:700;color:{c}}}
.mq .ok{{background:#fff3c4;font-weight:700}}
.mq .tip{{background:#fff7e6;border-left:4px solid #f0a020;padding:10px 14px;margin:14px 0}}
.mq table{{border-collapse:collapse;width:100%;margin:10px 0;font-size:.95em}}
.mq th,.mq td{{border:1px solid #ccd;padding:5px 8px;text-align:center}} .mq th{{background:#eef3f9}}
.mq .psg{{background:#fbfaf5;border:1px solid #e6e1cf;border-radius:8px;padding:12px 16px;font-family:Georgia,serif;margin:8px 0}}
.mq .slot{{border-style:dashed;font-family:inherit}} .mq .slot p{{margin:4px 0}}
.mq details.sum{{background:#fbfaf5;border:1px dashed #e6e1cf}}
.mq .small{{color:#666;font-size:.9em}}
</style>"""

def e(s): return html.escape(s)

def dl_box(extra=""):
    return f"""<div class="dl"><p><b>📥 자료 받기 — EBSi 공식 자료</b></p>
<p>문제지 · 정답과 해설 · 듣기 음원(MP3) · 듣기 대본은 EBSi에서 무료로 받을 수 있습니다.<br>
<a href="{EBSI}" target="_blank" rel="noopener">EBSi 기출문제 바로가기 ›</a><br>
<span class="small">{e(META['ebsi_path'])} 선택</span></p>{extra}</div>"""

def choices_html(ch):
    return '<ol class="ch">' + "".join(f"<li>{N[i]} {e(c)}</li>" for i, c in enumerate(ch)) + "</ol>"

SUMMARY = getattr(X_, 'SUMMARY', {})
SUM_FOLD = getattr(X_, 'SUM_FOLD', set())

def slot(label, n=None):
    # 지문 자리 — 교사가 쓴 우리말 요약을 보여 주고, 원문은 EBSi 문제지로 안내합니다.
    s = SUMMARY.get(n)
    if not s:
        return (f"<div class=\"psg slot\"><p class=\"small\">📄 <b>[지문]</b> {label} 지문은 EBSi 문제지에서 함께 보세요.</p></div>")
    note = f"<p class=\"small\" style=\"margin:6px 0 0\">원문은 EBSi 문제지 {label}에서 볼 수 있습니다.</p>"
    if n in SUM_FOLD:
        return (f"<details class=\"sum\"><summary>📄 지문 내용 요약 보기 <span class=\"small\">(먼저 풀어 본 뒤 펼쳐 보세요)</span></summary>"
                f"<p>{e(s)}</p>{note}</details>")
    return f"<div class=\"psg slot\"><p><b>📄 지문 요약</b> · {label}</p><p>{e(s)}</p>{note}</div>"

SLOT = {n: f"{n}번" for n in range(18, 41)}
SLOT.update({41: "41~42번", 43: "43~45번"})

def card(n, listening=False):
    stem, ch, extra = Q[n]
    pt = "<span class='pt'>[3점]</span>" if n in PT3 else ""
    body = ""
    given = ""
    if extra.startswith("GIVEN:"):
        given = extra[6:]; extra = ""
        body += f"<p class='psg'><b>주어진 문장</b><br>{e(given)}</p>"
    if not listening and n in SLOT: body += slot(SLOT[n], n)
    if given: body += "<p class='small'>①~⑤는 지문 속 위치입니다.</p>"
    body += extra
    if ch: body += choices_html(ch)
    a = ANS[n]
    if listening:
        clue, trap = L[n]
        ex = f"<p><b>핵심 단서</b> {e(clue)}</p><p><b>함정·팁</b> {e(trap)}</p>"
    else:
        ex = f"<p>{e(R[n])}</p>"
    return f"""<div class="card" id="q{n}"><p class="qh"><span class="no">{n}</span>{e(stem)}{pt}<span class="ty">{TYPE[n]}</span></p>{body}
<details><summary>정답과 해설 보기</summary><p class="ok">정답 {N[a-1]}</p>{ex}</details></div>"""

def answer_table():
    rows = ""
    for s in range(1, 46, 9):
        nums = list(range(s, min(s + 9, 46)))
        rows += "<tr><th>번호</th>" + "".join(f"<th>{i}{'*' if i in PT3 else ''}</th>" for i in nums) + "</tr><tr><th>정답</th>" + "".join(f"<td>{N[ANS[i]-1]}</td>" for i in nums) + "</tr>"
    return f"<table>{rows}</table><p class='small'>* 표시는 3점 문항 · 시도교육청 공식 정답 기준</p>"

NV = sum(len(v) for v in VOCAB.values())
SERIES = [("T1", "고등 영어 모의고사 해설", "정답표 + 독해 18~30번"), ("T2", "고등 영어 모의고사 해설", "듣기 1~17번 + 유사 듣기"),
          ("T3", "고등 영어 모의고사 해설", f"핵심 어휘 {NV}"), ("B1", "쌤의 영어 해설노트", "빈칸·무관한 문장 31~35번"),
          ("B2", "쌤의 영어 해설노트", "순서·삽입·요약 36~40번"),
          ("B3", "쌤의 영어 해설노트", "장문 41~45번 + 유사 독해")]

def series(cur, color, links=None):
    links = links or {}
    def item(k, b, t):
        label = f"{t} ({b})"
        if k in links and k != cur: label = f'<a href="{links[k]}">{t}</a> ({b})'
        return f"<li>{'<b>' if k == cur else ''}{label}{' ← 지금 보는 글</b>' if k == cur else ''}</li>"
    li = "".join(item(*x) for x in SERIES)
    return f"<div class='dl' style='border-color:{color}'><p><b>📚 {X} 영어 원스톱 해설 시리즈</b></p><ol>{li}</ol><p class='small'>여섯 편이면 1번부터 45번까지 모든 문항의 발문·선택지·정답·해설을 볼 수 있습니다.</p></div>"

def page(title, img, alt, color, inner):
    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><!-- 글 제목: {e(title)} --><title>{e(title)}</title>{css(color)}</head><body style="margin:0;padding:16px;background:#fff">
<div class="mq"><p><img src="{img}" alt="{e(alt)}" style="width:100%;border-radius:8px"></p>
{inner}</div></body></html>"""

def table_html(rows):
    h = "<tr>" + "".join(f"<th>{e(c)}</th>" for c in rows[0]) + "</tr>"
    return "<table>" + h + "".join("<tr>" + "".join(f"<td>{e(c)}</td>" for c in r) + "</tr>" for r in rows[1:]) + "</table>"

def listen_card(it):
    lines = "<br>".join(f"<b>{w}:</b> {e(t)}" for w, t in it['script'])
    tbl = table_html(it['table']) if 'table' in it else ""
    return f"""<div class="card"><p class="qh"><span class="no">유사</span>{e(it['stem'])}<span class="ty">{it['type']}</span></p>
<audio controls preload="none" style="width:100%" src="listen_{it['id']}.mp3"></audio>{tbl}
{choices_html(it['choices'])}
<details><summary>정답과 해설 보기</summary><p class="ok">정답 {N[it['ans']-1]}</p><p>{e(it['expl'])}</p></details>
<details><summary>듣기 대본 보기</summary><p class="small" style="font-family:Georgia,serif">{lines}</p></details></div>"""

def read_card(it):
    p = ""
    if 'parts' in it:
        p = f"<div class='psg'>{e(it['given'])}</div>" + "".join(f"<p class='psg'>({k}) {e(t)}</p>" for k, t in it['parts'])
    else:
        p = f"<p class='psg'><b>주어진 문장</b><br>{e(it['given'])}</p><div class='psg'>{e(it['passage'])}</div>"
    return f"""<div class="card"><p class="qh"><span class="no">유사</span>{e(it['stem'])}<span class="ty">{it['type']}</span></p>{p}
{choices_html(it['choices'])}
<details><summary>정답과 해설 보기</summary><p class="ok">정답 {N[it['ans']-1]}</p><p>{e(it['expl'])}</p></details></div>"""

HOW = "<div class='tip'><b>이렇게 활용하세요</b> — 문항마다 발문과 지문, 선택지를 보고 먼저 답을 고른 뒤 '정답과 해설 보기'를 눌러 확인하세요. 문제지는 위 EBSi 링크에서 무료로 받을 수 있습니다.</div>"
DATE = f"{META['date']} 시행 · {META['grade']} {EXAM}"
TAGS = f"{SHORT} 모의고사, 2026 {META['month']} 학평, {META['grade']} 영어 정답, {META['grade']} 영어 해설, {EXAM}, 영어 모의고사 해설"

TITLES = {
 "T1": f"{X} 영어 모의고사 정답 및 해설 (18~30번)",
 "T2": f"{X} 영어 듣기 1~17번 해설 + 유사 문제",
 "T3": f"{X} 영어 모의고사 핵심 어휘 정리",
 "B1": f"{X} 영어 빈칸 31~35번 해설",
 "B2": f"{X} 영어 순서·삽입·요약 36~40번 해설",
 "B3": f"{X} 영어 장문 41~45번 해설 + 유사 문제",
}

def build(links=None):
    links = links or {}
    out = {}
    lt = LISTEN
    t1 = f"""<p class="small">{DATE} · 영어 영역</p>
<p>{X} 영어 모의고사를 한 번에 정리했습니다. 이 글에는 전 문항 정답표와 독해 18~30번의 발문·선택지·정답·해설을 담았고, 듣기와 나머지 독해 문항은 아래 시리즈 글로 이어집니다. 문제지와 듣기 음원은 EBSi 공식 링크로 바로 받을 수 있습니다.</p>
{dl_box()}{series('T1', NAVY, links)}
<h2>1. 정답표 (1~45번)</h2>{answer_table()}
<h2>2. 한눈에 보는 출제 경향</h2><p>{X_.TREND}</p>
{HOW}
<h2>3. 독해 18~30번 문항별 해설</h2>{''.join(card(n) for n in range(18, 31))}
<div class="tip"><b>다음 글</b> — 듣기 1~17번은 시리즈 2편, 빈칸 31~35번과 36~45번은 '쌤의 영어 해설노트'에서 이어집니다.</div>
<p class="small">태그: {TAGS}</p>"""
    out['T1'] = page(TITLES['T1'], f"mock_{C}_answer.png", f"{X} 영어 모의고사 정답 및 해설", NAVY, t1)

    kinds = " · ".join(it['type'].split(' (')[0] for it in lt)
    t2 = f"""<p class="small">{DATE} · 영어 듣기</p>
<p>{X} 영어 듣기 1~17번을 문항별로 정리했습니다. 발문과 선택지를 보며 EBSi 음원을 다시 듣고, 정답을 고른 뒤 '정답과 해설 보기'를 눌러 핵심 단서와 함정을 확인하세요. 글 끝에는 같은 유형으로 새로 만든 <b>유사 듣기 문제 {len(lt)}개</b>가 있어 이 글 안에서 바로 들으며 연습할 수 있습니다.</p>
{dl_box("<p class='small'>듣기는 음원을 틀어 놓고 문항 카드를 보며 푸는 것을 권합니다. 16~17번은 두 번 들려줍니다.</p>")}{series('T2', NAVY, links)}
<h2>1. 듣기 1~17번 문항별 해설</h2>{''.join(card(n, True) for n in range(1, 18))}
<h2>2. 쌤이 만든 유사 듣기 문제</h2><p>이번 시험의 {kinds} 유형을 새로 만든 문제입니다. 재생 버튼을 누르고 풀어 보세요.</p>
{''.join(listen_card(it) for it in lt)}
<div class="tip"><b>듣기 점수 올리는 습관</b> — 틀린 문항은 대본을 보며 한 번, 대본 없이 한 번 더 들으세요. 놓친 구간을 받아쓰면 숫자·요일·조건 같은 함정에 강해집니다.</div>
<p class="small">태그: {SHORT} 영어 듣기, 2026 {META['month']} 학평 듣기, {META['grade']} 영어 듣기 해설, 영어 듣기 평가, 모의고사 듣기</p>"""
    out['T2'] = page(TITLES['T2'], f"mock_{C}_listen.png", f"{X} 영어 듣기 1~17번 해설", NAVY, t2)

    def vrange(k):
        return {41: "41~42번", 43: "43~45번"}.get(k, f"{k}번")
    vt = "".join(f"<h3>{vrange(k)} · {TYPE[k] if k not in (41, 43) else '장문'}</h3><table><tr><th>어휘</th><th>뜻</th></tr>" +
                 "".join(f"<tr><td style='text-align:left'><b>{e(w)}</b></td><td style='text-align:left'>{e(m)}</td></tr>" for w, m in v) + "</table>"
                 for k, v in sorted(VOCAB.items()))
    keys = getattr(X_, 'VOCAB_KEY', [])
    keyhtml = ("<h2>이번 시험에서 특히 중요한 표현</h2><ul>" + "".join(f"<li><b>{e(a)}</b> ({e(b)}) — {e(c)}</li>" for a, b, c in keys) + "</ul>") if keys else ""
    t3 = f"""<p class="small">{DATE} · 영어 독해 어휘</p>
<p>{X} 영어 모의고사 독해(18~45번)에서 꼭 알아야 할 어휘 {NV}개를 문항별로 모았습니다. 시험지를 다시 펴 놓고 지문 속에서 단어를 찾아가며 보면 기억에 훨씬 오래 남습니다.</p>
{dl_box()}{series('T3', NAVY, links)}
<div class="tip"><b>이렇게 공부하세요</b> — ① 뜻을 가리고 영어만 보며 소리 내어 뜻 말하기 → ② 틀린 단어에 표시 → ③ 표시한 단어만 지문에서 찾아 문장째 다시 읽기. 하루 세 문항씩이면 열흘 안에 끝납니다.</div>
<h2>문항별 핵심 어휘</h2>{vt}{keyhtml}
<p class="small">※ 어휘 뜻은 지문 문맥에 맞춘 뜻입니다.</p>
<p class="small">태그: {SHORT} 모의고사 단어, {META['grade']} 영어 어휘, 2026 {META['month']} 학평 어휘, 모의고사 단어장, 영어 단어 정리</p>"""
    out['T3'] = page(TITLES['T3'], f"mock_{C}_vocab.png", f"{X} 영어 모의고사 핵심 어휘 정리", NAVY, t3)

    b1 = f"""<p class="small">{DATE} · 영어 31~35번</p>
<p>{X} 영어에서 점수를 가장 많이 가른 빈칸 31~34번과 무관한 문장 35번입니다. 문항마다 지문과 선택지를 보고 먼저 풀어 본 뒤, 해설에서 <b>빈칸 단서 → 정답 근거 → 오답이 틀린 이유</b>를 확인하세요.</p>
{dl_box()}{series('B1', GREEN, links)}
<div class="tip"><b>빈칸 4단계</b> — ① 빈칸 문장 먼저 읽기 ② 빈칸을 다시 풀어 주는 문장(In other words, 바로 뒤 문장) 찾기 ③ 선택지 보기 전에 우리말로 답 예측 ④ 예측과 가장 가까운 선택지 고르기<br>{e(getattr(X_, 'BLANK_TIP', ''))}</div>
<h2>문항별 해설</h2>{''.join(card(n) for n in range(31, 36))}
<p class="small">라벨: {SHORT} 모의고사, {META['grade']} 영어 빈칸, 2026 {META['month']} 학평, 영어 빈칸 추론, 모의고사 해설</p>"""
    out['B1'] = page(TITLES['B1'], f"bs_{C}_blank.png", f"{X} 영어 빈칸 31~35번 해설", GREEN, b1)

    b2 = f"""<p class="small">{DATE} · 영어 36~40번</p>
<p>{X} 영어 36~40번(순서, 삽입, 요약)을 정리했습니다. 이 유형들은 <b>연결어 · 지시어 · 대비 구조</b>라는 세 가지 단서로 풀립니다. 문항마다 지문 요약과 선택지를 보고 먼저 풀어 본 뒤 해설을 확인하세요.</p>
{dl_box()}{series('B2', GREEN, links)}
<div class="tip"><b>순서·삽입 3단서</b> — ① However·In contrast 같은 연결어 ② this·these·such 같은 지시어가 가리키는 대상 ③ 앞뒤 문장의 대비(예전↔지금, 일반↔예외)</div>
<h2>문항별 해설</h2>{''.join(card(n) for n in range(36, 41))}
<p class="small">라벨: {SHORT} 모의고사, {META['grade']} 영어 순서 삽입, 2026 {META['month']} 학평, 영어 요약문, 모의고사 해설</p>"""
    out['B2'] = page(TITLES['B2'], f"bs_{C}_order.png", f"{X} 영어 36~40번 해설", GREEN, b2)

    b3 = f"""<p class="small">{DATE} · 영어 41~45번</p>
<p>{X} 영어 장문 41~45번을 정리했습니다. 41~42번은 글 전체의 흐름과 어휘, 43~45번은 이야기의 순서·지칭·세부 내용을 묻습니다. 글 끝에는 같은 유형으로 새로 만든 <b>유사 독해 문제 {len(READ)}개</b>가 지문까지 모두 실려 있어 바로 연습할 수 있습니다.</p>
{dl_box()}{series('B3', GREEN, links)}
<div class="tip"><b>장문 푸는 순서</b> — 41~42번은 제목을 먼저 정하고 (a)~(e)를 그 흐름에 대입하세요. 43~45번은 45번(내용 일치) 선택지를 먼저 읽고 본문으로 들어가면 순서와 지칭이 함께 잡힙니다.</div>
<h2>1. 문항별 해설</h2>{''.join(card(n) for n in range(41, 46))}
<h2>2. 쌤이 만든 유사 독해 문제</h2>{''.join(read_card(it) for it in READ)}
<p class="small">라벨: {SHORT} 모의고사, {META['grade']} 영어 장문, 2026 {META['month']} 학평, 영어 장문 독해, 모의고사 해설</p>"""
    out['B3'] = page(TITLES['B3'], f"bs_{C}_long.png", f"{X} 영어 41~45번 해설", GREEN, b3)
    return out

if __name__ == "__main__":
    for k, v in build().items():
        open(f"{OUT}{C}_{k}.html", 'w', encoding='utf-8').write(v)
    print("ok", NV)
