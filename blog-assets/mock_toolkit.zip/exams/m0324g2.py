# 2026학년도 3월 고2 전국연합학력평가 (2026.3.24) — 영어
META = dict(code="0324g2", label="2026년 3월 고2", date="2026년 3월 24일", grade="고2", month="3월",
            ebsi_path="기출문제 → 전국연합학력평가 → 2026년 → 3월 → 고2 → 영어")

ANS = [int(x) for x in "1 3 2 5 2 2 1 4 5 2 2 3 1 1 4 1 4 5 1 5 2 4 2 2 4 3 3 4 4 3 1 5 5 4 4 5 2 4 3 1 3 5 2 3 3".split()]
ANS = {i + 1: a for i, a in enumerate(ANS)}
PT3 = {6, 14, 15, 21, 24, 33, 34, 37, 39, 42}

Q = {
1: ("다음을 듣고, 남자가 하는 말의 목적으로 가장 적절한 것을 고르시오.", ["학교 신문 이름의 공모를 안내하려고","학교 신문에 게재할 기사를 모집하려고","학교 신문 창간 기념식 개최를 공지하려고","학교 신문 동아리의 지원 절차를 설명하려고","학교 신문 디자인 선호도 조사를 실시하려고"], ""),
2: ("대화를 듣고, 여자의 의견으로 가장 적절한 것을 고르시오.", ["친구 사이라도 예의를 갖추어 행동해야 한다.","논쟁 상황에서는 잠시 침묵을 지키는 것이 좋다.","자신의 감정을 솔직하게 표현하는 것이 중요하다.","상대방의 입장에서 먼저 생각하고 이해해야 한다.","의견이 다를 때는 이성적으로 판단하려 노력해야 한다."], ""),
3: ("다음을 듣고, 남자가 하는 말의 요지로 가장 적절한 것을 고르시오.", ["선택의 기준은 개인의 필요와 처한 상황에 따라 달라진다.","결정 상황에서 처음 정한 선택이 가장 바람직한 경우가 많다.","빠르고 정확한 판단은 분석적 사고력이 뒷받침될 때 가능하다.","중요한 결정에는 주변 사람들의 조언을 구하는 것이 도움이 된다.","하나의 결론만 고집하기보다 여러 가능성을 살피는 것이 좋다."], ""),
4: ("대화를 듣고, 그림에서 대화의 내용과 일치하지 않는 것을 고르시오.", [], "<p class='small'>그림: 호텔 객실 — ① 나란히 놓인 침대 세 개 ② 구석의 스탠드 ③ 바다가 보이는 창문 ④ 둥근 탁자 ⑤ 탁자 위의 꽃병</p>"),
5: ("대화를 듣고, 남자가 할 일로 가장 적절한 것을 고르시오.", ["쓰레기봉투 가져가기","바람막이 빌려주기","샌드위치 만들기","간식 구매하기","등산로 정하기"], ""),
6: ("대화를 듣고, 여자가 지불할 금액을 고르시오.", ["$33","$39","$40","$43","$46"], ""),
7: ("대화를 듣고, 여자가 클라우드 서비스 구독을 취소하려는 이유를 고르시오.", ["회사에서 접속이 불가능해서","서비스 이용 요금이 너무 비싸서","스마트폰 전용 앱을 지원하지 않아서","저장 용량에 만족하지 못해서","서버 오류가 자주 발생해서"], ""),
8: ("대화를 듣고, 역사 강연에 관해 언급되지 않은 것을 고르시오.", ["주제","강연자","날짜","참가비","장소"], ""),
9: ("2026 World Folk Dance Festival에 관한 다음 내용을 듣고, 일치하지 않는 것을 고르시오.", ["3월 27일 금요일에 열린다.","여섯 개의 댄스팀이 무대에 오른다.","민속춤 의상을 입어 볼 수 있다.","공연 후 공연자들과 함께 사진을 찍을 수 있다.","방문객 모두에게 특별 기념품을 증정한다."], ""),
10: ("다음 표를 보면서 대화를 듣고, 남자가 구매할 달리기용 조끼를 고르시오.", [],
     "<table><tr><th></th><th>Model</th><th>Price</th><th>Visibility Features</th><th>Weight</th><th>Bottle Holders</th></tr>"
     "<tr><td>①</td><td>A</td><td>$17</td><td>None</td><td>Medium</td><td>2</td></tr>"
     "<tr><td>②</td><td>B</td><td>$25</td><td>Reflective Strips</td><td>Lightweight</td><td>1</td></tr>"
     "<tr><td>③</td><td>C</td><td>$27</td><td>Reflective Strips</td><td>Lightweight</td><td>2</td></tr>"
     "<tr><td>④</td><td>D</td><td>$29</td><td>LED Lights</td><td>Medium</td><td>1</td></tr>"
     "<tr><td>⑤</td><td>E</td><td>$35</td><td>LED Lights</td><td>Lightweight</td><td>1</td></tr></table>"),
11: ("대화를 듣고, 남자의 마지막 말에 대한 여자의 응답으로 가장 적절한 것을 고르시오.", ["You’re too late. The train already left five minutes ago.","That’s tight. You need to hurry after you get off.","I agree. There’ll be less traffic tomorrow.","That’s my fault. I’ll leave earlier next time.","No problem. I can give you a ride to the station."], ""),
12: ("대화를 듣고, 여자의 마지막 말에 대한 남자의 응답으로 가장 적절한 것을 고르시오.", ["Good job. I feel proud of you finishing the work.","You’ll be fine. That job doesn’t require a uniform.","Don’t worry. Just do your best and trust yourself.","You’re right. Many students are looking for part-time jobs.","It won’t matter. Some part-time jobs start in the afternoon."], ""),
13: ("대화를 듣고, 남자의 마지막 말에 대한 여자의 응답으로 가장 적절한 것을 고르시오.", ["That’s perfect. Thank you so much for doing that.","Too bad. We could have ordered the T-shirts.","Good idea. I can help you right now.","Not really. We can just use the original design.","I agree. We’d better ask the printing shop to fix it."], ""),
14: ("대화를 듣고, 여자의 마지막 말에 대한 남자의 응답으로 가장 적절한 것을 고르시오.", ["Great. Let’s use the service and enjoy the day.","Never mind. I’d rather stay in the hotel tomorrow.","Okay. We can take our luggage with us the whole day.","I’m sorry. I totally forgot to cancel our hotel reservation.","Right. We can come back here and pick up our suitcases."], ""),
15: ("다음 상황 설명을 듣고, Hailey가 Brian에게 할 말로 가장 적절한 것을 고르시오.", ["Do you mind sharing it again in the class group chat?","I didn’t get the photo. Did you send it in another chat?","The photos aren’t clear. Could you share different ones?","I’m not comfortable with the photos, so can you remove them?","How about taking pictures with all the classmates instead?"], ""),
16: ("[16~17] 여자가 하는 말의 주제로 가장 적절한 것은?", ["foods that seem healthy but may be misleading","nutritional benefits of eating healthy foods","the role of packaging in food marketing","how low-calorie foods help with weight control","why people can’t trust nutrition labels completely"], ""),
17: ("언급된 음식이 아닌 것은?", ["light salad dressing","nut bars","wheat bread","fruit juice","veggie chips"], ""),
18: ("다음 글의 목적으로 가장 적절한 것은?", ["스포츠 센터의 주차 관리 직원 채용을 공고하려고","공사 지연으로 인한 휴관 기간 연장을 공지하려고","무단 주차 시 차량이 견인될 수 있음을 경고하려고","새로운 차량 등록 시스템의 도입 일정을 안내하려고","주차장 보수 공사 기간 중 임시 주차장 이용을 요청하려고"], ""),
19: ("다음 글에 드러난 Oliver의 심경 변화로 가장 적절한 것은?", ["nervous → relieved","curious → regretful","bored → thrilled","lonely → indifferent","impressed → doubtful"], ""),
20: ("다음 글에서 필자가 주장하는 바로 가장 적절한 것은?", ["새로운 일을 시작할 때는 방해 요소를 없애야 한다.","스트레스 관리를 위해 정기적으로 휴식을 취해야 한다.","갈등 상황에서는 다양한 가치를 모두 균형 있게 고려해야 한다.","변화의 시기를 직업 전문성 향상의 기회로 활용해야 한다.","전환기를 새로운 네트워크 구축의 발판으로 삼아야 한다."], ""),
21: ("밑줄 친 having a “blank face”가 다음 글에서 의미하는 바로 가장 적절한 것은?", ["avoiding the urge to resolve students’ emotional conflicts","suppressing evaluative responses to students’ answers","treating all answers as correct to facilitate learning","indicating misconceptions in mathematical discussions","controlling facial expressions to maintain strict authority"], ""),
22: ("다음 글의 요지로 가장 적절한 것은?", ["장거리 여행객을 위한 휴식 공간 마련이 필수적이다.","배차 간격을 줄여야 통근객의 신속한 이동이 가능하다.","실시간 교통 정보를 제공하여 승객 편의를 증진할 수 있다.","도시 간 이동과 통근의 동선을 분리해 혼선을 막을 필요가 있다.","역 내부를 아름답고 쾌적한 환경으로 조성하는 것이 중요하다."], ""),
23: ("다음 글의 주제로 가장 적절한 것은?", ["various lighting cues for inducing an active audience engagement","purposeful lighting for shaping scenes and shifts in performance","ways to mark the passage of time in a scene with lighting","commercial effects of a dramatic lighting performance","technical process of designing performance lighting"], ""),
24: ("다음 글의 제목으로 가장 적절한 것은?", ["Headphones vs. Loudspeakers: Which One Wins?","When Space Enters the Sound’s Route to the Ear","Musical Instruments as Key Players in Sound Quality","From Signal to Sound: Principles of Sound Transmission","Chasing Consistent Sound Effects Through Shifting Spaces"], ""),
25: ("다음 도표의 내용과 일치하지 않는 것은?", [],
     "<p class='small'>도표: 후기 요청 방식별 응답 의향이 있는 미국 소비자 비율(%) · 복수 응답</p><table><tr><th>방식</th><th>2023</th><th>2024</th><th>2025</th></tr>"
     + "".join(f"<tr><td>{a}</td><td>{b}</td><td>{c}</td><td>{d}</td></tr>" for a, b, c, d in [("이메일", 34, 32, 40), ("대면", 33, 28, 27), ("소셜 미디어", 31, 27, 27), ("문자 메시지", 23, 25, 27)])
     + "</table><p class='small'>선택지 ①~⑤는 도표를 설명하는 지문 속 다섯 문장입니다.</p>"),
26: ("Dennis William Sciama에 관한 다음 글의 내용과 일치하지 않는 것은?", ["Malvern College에서 수학과 물리학 교육을 받았다.","1953년에 물리학 박사 학위를 취득했다.","자신의 견해를 바꾸어 Big Bang model에 반대했다.","실험 물리학에 대한 탁월한 기여로 Guthrie Medal을 받았다.","Stephen Hawking에 관한 영화에서 소개되었다."], ""),
27: ("2026 Student Smart Farming Program에 관한 다음 안내문의 내용과 일치하지 않는 것은?", ["학생들을 대상으로 1년간 운영된다.","참가자는 프로그램 시작 시 워크숍에 참석해야 한다.","참가자는 매주 진행되는 멘토링 세션에 참가해야 한다.","최우수 학생들은 농업 연구 기관을 방문할 것이다.","개인 또는 최대 세 명으로 구성된 팀으로 지원할 수 있다."], ""),
28: ("Library of Things에 관한 다음 안내문의 내용과 일치하는 것은?", ["로그인하지 않아도 서비스를 이용할 수 있다.","방문 접수를 통해 대여 예약이 가능하다.","주중에만 예약한 물품을 수령할 수 있다.","대여 기간 연장은 한 번 가능하다.","대여료는 하루에 2달러이다."], ""),
29: ("다음 글의 밑줄 친 부분 중, 어법상 틀린 것은?", [], "<p>밑줄 친 부분: ① in which ② did have ③ made ④ occurring ⑤ its</p>"),
30: ("다음 글의 밑줄 친 부분 중, 문맥상 낱말의 쓰임이 적절하지 않은 것은?", [], "<p>밑줄 친 낱말: ① thorough ② less ③ facilitating ④ recognised ⑤ transferable</p>"),
31: ("[31~34] 다음 빈칸에 들어갈 말로 가장 적절한 것을 고르시오.", ["emotion","curiosity","familiarity","memory","ignorance"], ""),
32: ("다음 빈칸에 들어갈 말로 가장 적절한 것을 고르시오.", ["identified aesthetic appreciation with literary convention","preferred artistic value to practical value of objects","confined aesthetic experience to sensory pleasure","advocated for the reform of artistic techniques","argued against the separation of art from life"], ""),
33: ("다음 빈칸에 들어갈 말로 가장 적절한 것을 고르시오.", ["stand on the highest level of moral excellence","have sympathy for each other’s moral deficiency","come to an agreement on a set of moral values","be excluded from the judgment of moral superiority","fall within the range of application of moral standards"], ""),
34: ("다음 빈칸에 들어갈 말로 가장 적절한 것을 고르시오.", ["mistake contextual information for irrelevant data","analyse silence as the termination of a conversation","acquire human-likeness as well as a faster rate of speech","recognise silence not as an absence but as meaningful data","consider pause fillers to markedly disrupt conversational flow"], ""),
35: ("다음 글에서 전체 흐름과 관계 없는 문장은?", [], "<p class='small'>①~⑤는 지문 속 문장 번호입니다.</p>"),
36: ("[36~37] 주어진 글 다음에 이어질 글의 순서로 가장 적절한 것을 고르시오.", ["(A) - (C) - (B)","(B) - (A) - (C)","(B) - (C) - (A)","(C) - (A) - (B)","(C) - (B) - (A)"], ""),
37: ("주어진 글 다음에 이어질 글의 순서로 가장 적절한 것을 고르시오.", ["(A) - (C) - (B)","(B) - (A) - (C)","(B) - (C) - (A)","(C) - (A) - (B)","(C) - (B) - (A)"], ""),
38: ("[38~39] 글의 흐름으로 보아, 주어진 문장이 들어가기에 가장 적절한 곳을 고르시오.", [], "GIVEN:These in-character behaviors can be insufficient, however, to maintain the necessary amount of common ground about what is fictional in the world of the make-believe."),
39: ("글의 흐름으로 보아, 주어진 문장이 들어가기에 가장 적절한 곳을 고르시오.", [], "GIVEN:But the pressure changes we experience are trivial compared to the pressure range of the overall planetary environment."),
40: ("다음 글의 내용을 한 문장으로 요약하고자 한다. 빈칸 (A), (B)에 들어갈 말로 가장 적절한 것은?", [],
     "<table><tr><th></th><th>(A)</th><th>(B)</th></tr>" + "".join(f"<tr><td>{'①②③④⑤'[i]}</td><td>{a}</td><td>{b}</td></tr>" for i, (a, b) in enumerate([("exploration", "precede"), ("formalization", "precede"), ("confirmation", "follow"), ("investigation", "follow"), ("standardization", "accompany")])) + "</table>"),
41: ("[41~42] 윗글의 제목으로 가장 적절한 것은?", ["Balancing Narrative and Analysis in Research","How Numbers Stepped into the Field of History","From Data to Insight: The Power of Visualization","Visual Conventions Used in Numerical Processing","Cholera Outbreak: Why Social Studies Need Statistics"], ""),
42: ("밑줄 친 (a)~(e) 중에서 문맥상 낱말의 쓰임이 적절하지 않은 것은?", [], "<p>밑줄 친 낱말: (a) forefront (b) ordinary (c) sophisticated (d) demonstrated (e) intensifying</p>"),
43: ("[43~45] 주어진 글 (A)에 이어질 내용을 순서에 맞게 배열한 것으로 가장 적절한 것은?", ["(B) - (D) - (C)","(C) - (B) - (D)","(C) - (D) - (B)","(D) - (B) - (C)","(D) - (C) - (B)"], ""),
44: ("밑줄 친 (a)~(e) 중에서 가리키는 대상이 나머지 넷과 다른 것은?", ["(a)","(b)","(c)","(d)","(e)"], ""),
45: ("윗글에 관한 내용으로 적절하지 않은 것은?", ["Aiden은 전설적인 예술가인 Rowan을 만나려고 먼 길을 떠났다.","Aiden은 며칠 밤낮으로 좌절한 채 돌을 응시했다.","Rowan은 Aiden이 가져온 풍경화들을 보며 칭찬했다.","Rowan은 Aiden에게 화려한 기교를 잊으라고 말했다.","Rowan에게 캔버스를 건네줄 때 Aiden의 손이 떨렸다."], ""),
}

L = {
1: ("교감 선생님이 곧 창간할 학교 신문의 이름을 학생들에게서 받는다며, QR 코드로 아이디어를 내 달라고 안내합니다. 뽑힌 이름을 낸 학생은 창간호에 소개됩니다.", "'기사 모집'(②)이나 '창간 기념식'(③)은 나오지 않습니다. 요청하는 대상이 '이름'이라는 점을 놓치지 마세요."),
2: ("친구에게 감정을 숨기면 거리만 생기고 오해가 커진다며, 솔직하게 털어놓는 것이 중요하다고 여러 번 말합니다.", "남자가 '어색해지기 싫다'고 하는 말에 끌려 ②번(침묵)을 고르기 쉽지만, 여자의 의견은 반대입니다."),
3: ("가게에서 고를 때 오래 고민할수록 좋은 결정을 할 것 같지만, 연구에 따르면 처음 고른 것이 진짜 선호를 반영해 가장 나은 경우가 많다고 말합니다.", "'여러 가능성을 살펴라'(⑤)는 남자가 오히려 경계하는 태도입니다."),
4: ("침대 세 개, 구석 스탠드, 바다가 보이는 창, 둥근 탁자까지는 대화와 같습니다. 탁자 위에는 '전기 찻주전자'가 있다고 했는데 그림에는 꽃병이 있습니다.", "그림 문제는 마지막에 언급되는 물건이 정답인 경우가 많습니다. 끝까지 집중하세요."),
5: ("등산로와 샌드위치는 여자 담당, 간식은 남자가 이미 샀습니다. 바람막이가 없다는 여자에게 남자가 여분을 빌려주겠다고 합니다.", "'이미 한 일'(간식 구매)과 '앞으로 할 일'(바람막이 빌려주기)을 구분하세요."),
6: ("어른 $20 × 1 + 아이 $10 × 2 = $40, 장식 세트 $3 × 2 = $6, 합계 $46에서 쿠폰 $7 할인 → $39.", "할인 전 금액 $46(⑤), 장식 세트를 빼먹은 $33(①)이 함정입니다."),
7: ("요금, 저장 용량, 서버 오류, 앱은 모두 문제가 없다고 하고, 회사 보안 정책이 바뀌어 회사에서 접속할 수 없다는 것이 이유입니다.", "남자가 하나씩 묻는 이유(요금·용량·오류)는 모두 오답 선택지입니다."),
8: ("주제(한국과 아일랜드의 독립 투쟁), 강연자(Stevens 교수), 날짜(4월 5일 오후 3시), 장소(국립역사박물관)는 나오지만 참가비는 나오지 않습니다.", "들으면서 선택지를 하나씩 지워 가세요."),
9: ("특별 기념품은 '선착순 50명'에게만 준다고 했으므로 '방문객 모두'는 틀립니다.", "입장료 무료 대상(Maplehurst 주민)과 기념품 대상(선착순 50명)을 헷갈리지 마세요."),
10: ("$30 미만(⑤ 제외) → 밤에 달리므로 LED나 반사띠(① 제외) → 가벼운 것(④ 제외) → 물병 홀더 1개 → ② B.", "조건을 들을 때마다 표에서 바로 지우면 마지막 조건 하나로 답이 정해집니다."),
11: ("기차는 20분 뒤 출발하는데 남자는 10분 뒤에야 도착한다고 하니, '빠듯하니 내리자마자 서둘러'라는 ②번이 자연스럽습니다.", "① '이미 떠났다'는 상황과 맞지 않습니다. 시간 정보를 정확히 들으세요."),
12: ("첫 아르바이트를 앞두고 실수할까 걱정하는 딸에게 '최선을 다하고 너 자신을 믿어'라고 격려하는 ③번이 맞습니다.", "걱정하는 상대에게는 위로·격려 응답이 정답인 경우가 많습니다."),
13: ("오늘 밤까지 디자인을 끝내 주겠다는 남자에게 '완벽해, 고마워'라고 답하는 ①번이 맞습니다.", "③번(지금 바로 도와줄게)은 여자가 디자인 프로그램을 못 다룬다는 말과 맞지 않습니다."),
14: ("호텔 간 짐 배달 서비스를 예약하겠다는 여자에게 '좋아, 그 서비스를 쓰고 하루를 즐기자'는 ①번이 이어집니다.", "③번은 짐을 들고 다니겠다는 뜻이라 대화 흐름과 반대입니다."),
15: ("자신이 나온 사진이 단톡방에 올라간 것이 불편해 Brian에게 삭제를 부탁하려는 상황이므로 ④번이 맞습니다.", "핵심 단어는 delete(삭제)입니다. '다시 올려 달라'(①)는 정반대입니다."),
16: ("건강해 보이지만 영양 성분표를 보면 그렇지 않은 음식들을 소개합니다.", "'포장의 역할'(③)이나 '저칼로리'(④)는 소재만 비슷한 오답입니다."),
17: ("라이트 샐러드드레싱, 견과류 바, 밀빵, 채소 칩은 언급되었고 과일 주스는 나오지 않습니다.", "16~17번은 두 번 들려줍니다. 두 번째 들을 때 목록을 확인하세요."),
}

R = {
18: "스포츠 센터가 지하 주차장 보수 공사 기간(4월 1~7일)에 정문 맞은편 임시 야외 주차장을 이용해 달라고 부탁하는 글입니다. we kindly ask you to use the temporary outdoor parking lot이 결정적인 문장입니다.",
19: "전학 첫날 급식실에서 혼자 불안해하던 Oliver가, 같은 반 친구가 먼저 다가와 말을 걸자 마음이 놓여 밝게 웃습니다. anxious·heavy sigh → at ease·smiled brightly이므로 nervous → relieved입니다.",
20: "새 환경에서 목표에만 집중하려고 관계를 끊는 것은 실수이며, 전환기를 새로운 네트워크를 만드는 발판(jumping-off point)으로 삼으라는 것이 필자의 주장입니다. 마지막 문장의 Instead of ~ use this transition이 핵심입니다.",
21: "교사가 학생의 답에 동의·비동의를 나타내는 말이나 몸짓을 하지 않는 것이 '무표정'의 의미입니다. 즉 학생 답에 대한 평가적 반응을 억누르는 ②번입니다. ③번처럼 '모든 답을 정답으로 취급'하는 것은 아닙니다.",
22: "느리게 움직이며 짐과 정보가 필요한 도시 간 여행객과, 서두르는 통근객의 동선을 충돌과 혼란을 피하도록 분리해야 한다는 요지입니다. These two types of traffic should be kept separate가 핵심 문장입니다.",
23: "조명 신호에는 배우처럼 '계기(motivation)'가 있어야 하고, 장면과 전환마다 조명이 무엇을 할지 물어야 한다는 글입니다. 주제는 장면과 전환을 만들어 가는 '목적 있는 조명'입니다.",
24: "헤드폰은 방이 소리 경로에 끼어들지 않아 어디서나 같게 들리지만, 스피커는 방이 신호 경로의 일부가 되어 방과 위치마다 다르게 들립니다. 제목은 '공간이 소리의 경로에 들어올 때'인 ②번입니다.",
25: "이메일과 대면 응답 비율의 차이는 2023년 1%p(34−33), 2024년 4%p(32−28)로 2024년에 더 큽니다. '더 작았다'는 ④번 문장이 도표와 일치하지 않습니다.",
26: "Sciama는 1960년대에 새 증거가 나오자 견해를 바꾸어 빅뱅 모델을 '받아들였습니다(accepted)'. 반대했다는 ③번이 틀립니다.",
27: "멘토링 세션은 '매주'가 아니라 '매월(monthly)' 열립니다. 안내문 문제에서는 빈도·날짜·금액 같은 숫자 정보를 꼭 대조하세요.",
28: "앱 로그인 필요(①×), 온라인 예약만 가능(②×), 월~일 수령(③×), 하루 2달러는 연체료일 뿐 대여는 무료(⑤×). 최대 7일, 한 번 연장 가능하다는 ④번만 일치합니다.",
29: "④번은 문장의 주어 The development of a true piano factory에 대한 본동사가 필요하므로 occurring을 과거 동사 occurred로 고쳐야 합니다. ②번 did have는 강조의 did로 맞습니다.",
30: "한 분야에만 몰두하면 지식과 기술의 폭이 좁아져 다양한 진로에 적응하는 능력을 '저해할(hindering)' 수 있다는 흐름입니다. 촉진한다(facilitating)는 ③번은 문맥과 반대입니다.",
31: "아이들은 상상한 것이 현실이 되지 않는다는 것을 알지만, 괴물처럼 무서운 것을 떠올릴 때는 그 이해가 흔들립니다. 빈칸은 이해를 방해하는 것이므로 두려움과 연결되는 ① emotion(감정)입니다.",
32: "Dewey는 미적 경험을 인간 삶의 생물학적·문화적 조건에 두고, 자아와 사물·사건 세계의 완전한 상호 침투에서 찾았습니다. 즉 예술과 삶을 떼어 놓는 데 반대한 ⑤번입니다. ③번은 Dewey가 부정한 '내면의 감각'에 가두는 관점입니다.",
33: "도덕적 우열은 같은 도덕 기준을 두 존재에 적용해 누가 더 충족하는지로 판단하므로, 두 존재 모두 도덕 기준의 적용 범위 안에 있어야 합니다. 그래서 도덕적 행위자가 아닌 동식물과 비교해 인간이 우월하다고 말할 수 없다는 결론이 이어집니다.",
34: "짧은 침묵을 '생각하는 중'으로 보이게 하고, 침묵을 적절한 소리로 채울 수 있다고 추론하는 모습에서 AI가 침묵을 단순한 공백이 아닌 의미 있는 데이터로 인식하기 시작했다고 볼 수 있습니다. 바로 뒤 Yet 문장이 '그래도 여전히 소리를 더 선호한다'고 뒤집는 구조입니다.",
35: "글은 인쇄술이 정보의 정확한 복제를 가능하게 했다는 내용인데, ④번은 콜럼버스 여행 일지의 '내용 수준'을 평가하는 문장이라 흐름과 무관합니다.",
36: "주어진 글(기원전 9500년의 농업) → (C) 수천 년간의 혁신과 늘어나는 인구 → (B) 2050년 인구 전망과 경작지의 한계 → (A) also로 정치·경제 요인을 덧붙이며 줄어드는 농지. (B)의 this need와 (A)의 also가 단서입니다.",
37: "주어진 글(엄마·아빠처럼 모든 언어에 있는 말) → (B) 다른 가족 관계를 더해 '친족 용어' 범주를 정의 → (A) And로 이어져 핵심 용어 설명 → (C) By contrast로 덜 중심적인 관계는 핵심 용어로 만들어 냄. (C)의 By contrast는 (A)의 core terms와 대조됩니다.",
38: "④ 앞까지는 역할에 몰입한 행동만으로 정보가 전달되는 예(피터 팬)이고, ④ 뒤는 At these times로 '역할에서 빠져나와' 정보를 주는 경우입니다. 그 사이에 '그러나 이런 행동만으로는 부족할 수 있다'는 주어진 문장이 들어가야 these times가 가리킬 대상이 생깁니다.",
39: "③ 앞은 '작은 압력 변화도 신진대사에 큰 영향을 준다', ③ 뒤는 '압력은 깊이에 따라 급격히 증가한다'입니다. 우리가 겪는 압력 변화는 행성 전체 범위에 비하면 미미하다는 주어진 문장이 들어가야 이야기가 행성 규모로 넘어갑니다.",
40: "자가 실험은 발견·탐색에 유리하고 전통적 실험은 다른 사람을 납득시키는 데 유리하므로, 자가 실험을 먼저 하고 전통적 실험이 뒤따르는 것이 가장 효율적입니다. (A) exploration, (B) precede입니다.",
41: "19세기 데이터의 증가로 시각화가 필요해졌고, 통계 분석이 정교해지며 시각화가 해석을 가능하게 하고 논증의 중심이 되었다는 글입니다. 제목은 ③ From Data to Insight: The Power of Visualization입니다.",
42: "시각적 단서로 작은 공간에 더 많은 정보를 담게 되었다면 인쇄물이 가진 2차원의 한계를 '심화'한 것이 아니라 '극복한(overcoming)' 것입니다. (e) intensifying이 문맥에 맞지 않습니다.",
43: "(A) Aiden이 Rowan의 오두막을 찾아옴 → (C) 들어가 풍경화를 펼치지만 Rowan은 돌을 건넴 → (B) 돌을 가져가 며칠 동안 관찰하며 아름다움을 발견 → (D) 며칠 후 그림을 들고 돌아옴. 정답 (C)-(B)-(D)입니다.",
44: "(a)(b)(d)(e)는 모두 Aiden이고, (c)는 정원으로 걸어가 돌을 집어 든 Rowan입니다.",
45: "Rowan은 Aiden의 풍경화를 빠르게 훑어보고 옆으로 밀어냈으며, Aiden이 기대한 평가를 하지 않았습니다. 칭찬했다는 ③번이 틀립니다.",
}

VOCAB = {
18: [("appreciate", "감사하다"), ("conduct", "시행하다"), ("maintenance", "보수 (공사)"), ("facility", "시설"), ("temporary", "임시의"), ("be committed to", "~에 전념하다"), ("inconvenience", "불편"), ("cooperation", "협조")],
19: [("grip", "꽉 쥐다"), ("weight", "부담"), ("anxious", "불안한"), ("sigh", "한숨"), ("invisible", "보이지 않는"), ("at ease", "긴장이 풀린, 편안한")],
20: [("master", "숙지하다"), ("distract", "주의를 분산시키다"), ("unidimensional", "일차원적인"), ("remedy", "치료제"), ("inevitably", "불가피하게"), ("transition", "전환기"), ("counterbalance", "상쇄하다"), ("jumping-off point", "발판")],
21: [("acceptance", "수용"), ("regardless of", "~과 상관없이"), ("misconception", "오개념"), ("forefront", "전면"), ("confront", "마주하다"), ("derogatory", "비하하는"), ("verbal", "언어적인"), ("defend", "방어하다")],
22: [("intercity", "도시 간의"), ("retrieve", "되찾다"), ("connection", "환승"), ("commuter", "통근객"), ("route", "경로; 유도하다"), ("concise", "간결한"), ("desirable", "바람직한")],
23: [("cue", "신호, 큐"), ("trigger", "이끌어 내다"), ("motivation", "계기"), ("intensity", "강도"), ("subtle", "미묘한"), ("atmosphere", "분위기"), ("threatening", "위협적인")],
24: [("impose A on B", "A를 B에 부여하다"), ("characteristics", "특성"), ("remarkable", "놀라운"), ("acoustical", "음향의"), ("playback", "재생"), ("path", "경로")],
25: [("consumer", "소비자"), ("review", "후기"), ("in person", "대면하여"), ("except for", "~을 제외하고"), ("gap", "차이")],
26: [("take over", "물려받다"), ("pursue", "추구하다"), ("doctoral degree", "박사 학위"), ("steady-state theory", "정상 우주론"), ("evidence", "증거"), ("outstanding", "탁월한"), ("contribution", "기여")],
27: [("agricultural", "농업의"), ("crop", "작물"), ("mentoring", "멘토링"), ("submit", "제출하다"), ("free of charge", "무료의")],
28: [("borrow", "빌리다"), ("reserve", "예약하다"), ("household", "가정용의"), ("gear", "장비"), ("extension", "연장"), ("late fee", "연체료")],
29: [("manufacturing", "제조"), ("apprentice", "견습생"), ("trade", "업계"), ("specialist", "전문가"), ("efficiency", "효율성"), ("casting", "주조")],
30: [("thesis-based", "논문 기반의"), ("thorough", "철저한"), ("absorbed in", "~에 몰두한"), ("breadth", "폭"), ("interdisciplinary", "학제 간의"), ("implement", "시행하다"), ("transferable", "전이 가능한"), ("academia", "학계")],
31: [("imaginary", "상상의"), ("with respect to", "~에 관해"), ("disrupt", "방해하다"), ("causal relation", "인과 관계"), ("pretend", "가장하다"), ("avoidance", "회피")],
32: [("liberation", "해방"), ("aesthetic", "미적인"), ("gratification", "만족감"), ("degrade", "격하하다"), ("prevalent", "지배적인"), ("contemporary", "현대의"), ("interpenetration", "상호 침투"), ("intensify", "강화하다")],
33: [("validly", "타당하게"), ("superior", "우월한"), ("on the ground that", "~라는 근거로"), ("agent", "행위자"), ("merit", "장점"), ("deficiency", "결함"), ("entity", "존재"), ("fulfill", "충족하다")],
34: [("artificial", "인공적인"), ("supplement", "보완"), ("cadence", "억양"), ("interlocutor", "대화 상대"), ("reinforce", "강화하다"), ("illusion", "환상"), ("inference", "추론"), ("substantial", "(상당히) 긴")],
35: [("standardization", "표준화"), ("reproduction", "복제"), ("manuscript", "필사본"), ("authentic", "진짜의"), ("distribute", "배포하다"), ("novelty", "독창성"), ("accuracy", "정확성")],
36: [("archaeological", "고고학적인"), ("cultivate", "경작하다"), ("density", "밀도"), ("decline", "감소하다"), ("topography", "지형"), ("millennia", "수천 년"), ("productivity", "생산성")],
37: [("kinship", "친족"), ("probability", "확률"), ("core", "핵심의"), ("terminology", "어휘 체계"), ("typological", "유형학의"), ("modify", "변형하다")],
38: [("make-believe", "가상 역할 놀이"), ("in-character", "역할에 충실한"), ("insufficient", "불충분한"), ("common ground", "공통된 이해"), ("fictional", "허구의"), ("emit", "발산하다")],
39: [("intuition", "직관"), ("uniformly", "균일하게"), ("assume", "추측하다"), ("bias", "편향"), ("metabolism", "신진대사"), ("trivial", "미미한"), ("interior", "내부")],
40: [("self-experimentation", "자가 실험"), ("conventional", "전통적인"), ("resemble", "비슷하다"), ("hypothesis", "가설"), ("exploratory", "탐색적인"), ("parameter", "매개 변수"), ("optimize", "최적화하다"), ("validation", "타당성")],
41: [("emergence", "출현"), ("visualize", "시각화하다"), ("numerical", "수치의"), ("sparing", "절제된"), ("lag", "뒤처지다"), ("sophisticated", "정교한"), ("outbreak", "발병"), ("convey", "전달하다")],
43: [("aspiring", "의욕적인"), ("cottage", "오두막"), ("reluctantly", "마지못해"), ("lump", "덩어리"), ("eagerly", "간절히"), ("mock", "조롱하다"), ("dull", "칙칙한")],
}

VOCAB_KEY = [("jumping-off point", "발판", "20번 주장 — 전환기를 새 네트워크의 발판으로"),
             ("blank face", "무표정", "21번 함축 — 답에 대한 평가 반응을 드러내지 않기"),
             ("signal path", "신호 경로", "24번 제목 — 방이 소리 경로에 들어오는가"),
             ("misconception", "오개념", "21번 — 틀린 답의 뿌리"),
             ("interpenetration", "상호 침투", "32번 빈칸 — Dewey가 미적 경험을 찾은 곳"),
             ("precede", "~에 앞서다", "40번 요약 (B) — 자가 실험이 먼저")]

TREND = ("<b>듣기</b>는 학교 신문, 친구 관계, 호텔 객실, 등산 준비처럼 생활 소재가 중심이었고, 6번 금액과 14·15번 응답 문항이 3점이었습니다. "
         "<b>독해 앞부분</b>은 21번 함축 의미(수업 중 '무표정')와 24번 제목(방과 소리 경로)이 3점으로 까다로웠습니다. "
         "<b>빈칸 31~34번</b>은 33번(도덕적 우월성)과 34번(AI와 침묵)이 3점으로 추상적인 논증 글이었고, <b>간접 쓰기</b>는 37번 순서, 39번 삽입, 42번 장문 어휘가 3점이었습니다. "
         "고1 3월보다 지문의 추상도가 한 단계 높아져, 3점 문항이 많은 빈칸·간접 쓰기에서 점수 차이가 났습니다.")
BLANK_TIP = "고2 3월 빈칸은 바로 뒤에 이어지는 That is, Indeed, therefore 문장이 빈칸을 풀어 주는 경우가 많았습니다. 빈칸 문장 뒤 두 문장까지 꼭 읽으세요."

THUMB_ANS = [[6, 1, True], [14, 0, True], [15, 3, True], [21, 1, True], [24, 1, True], [33, 4, True], [34, 3, True], [37, 1, True], [39, 2, True], [42, 4, True]]
THUMB_LISTEN = [[1, 0, False], [2, 2, False], [4, 4, False], [6, 1, True], [7, 0, False], [10, 1, False], [11, 1, False], [13, 0, False], [14, 0, True], [15, 3, True]]
THUMB_BLANK = [["31 괴물 상상 실험", "①"], ["32 Dewey와 미적 경험", "⑤"], ["33 같은 기준 적용 범위", "⑤"], ["34 AI가 침묵을 읽다", "④"], ["35 인쇄술과 표준화", "④"]]
THUMB_ORDER = [["36·37 순서", "⑤ · ②"], ["38·39 삽입", "④ · ③"], ["40 요약", "①"], ["41·42 장문", "③ · ⑤"], ["43~45 장문", "② · ③ · ③"]]

SUM_FOLD = set(range(18, 29))
SUMMARY = {
18: "시립 스포츠 센터가 회원들에게 보내는 안내문입니다. 지하 주차장 보수 공사로 4월 1일부터 7일까지 지하 주차장을 쓸 수 없으며, 그동안 정문 맞은편에 마련한 임시 야외 주차장을 이용해 달라고 부탁하고 불편에 대해 양해를 구합니다.",
19: "전학 온 Oliver가 시끄러운 급식실에서 쟁반을 꽉 쥔 채 구석에 혼자 앉아, 남은 하루를 버틸 수 있을지 걱정합니다. 그때 같은 수학 수업을 듣는 친구가 아까 펜을 빌려줘서 고맙다며 맞은편에 앉자, Oliver를 둘러싼 보이지 않는 벽이 녹아내리고 그는 밝게 웃습니다.",
20: "새로운 환경에 들어가면 많은 사람이 일에만 집중하려고 다른 사람이나 활동과의 연결을 줄이는데, 필자는 이것을 실수라고 봅니다. 그렇게 하면 그 시기에 쏟아지는 작은 스트레스를 상쇄할 거리가 사라지기 때문에, 전환기를 다른 방식으로 활용하라고 조언합니다.",
21: "수학 교실에서 서로 존중하는 학습 공동체를 만들려면 틀린 답까지 포함해 모든 생각을 받아들여야 한다는 글입니다. 교사가 답을 기록할 때 동의·비동의를 드러내는 말이나 몸짓을 하지 않아야 학생들이 정답을 교사에게서 찾지 않고 스스로 자기 생각을 변호하게 된다고 말합니다.",
22: "기차역 이용객을 도시 사이를 오가는 여행객과 통근객으로 나누어 비교합니다. 여행객은 짐이 많고 천천히 움직이며 쉴 곳과 정보가 필요하지만 통근객은 길에 익숙하고 서두른다는 차이를 짚고, 뉴욕 Grand Central Terminal처럼 층·승강장·동선을 나눈 사례를 소개합니다.",
23: "공연 조명은 여러 '조명 상태'로 이루어지고, 각 조명 신호(큐)에도 배우처럼 계기가 있어야 한다는 글입니다. 스위치를 켜는 장면처럼 분명한 경우부터 몇 분에 걸쳐 분위기를 바꾸는 경우까지 예를 들고, 장면과 전환마다 조명이 무엇을 할지 물어야 한다고 말합니다.",
24: "헤드폰 소리는 어디서 들어도 같지만 스피커 소리는 방마다, 놓는 위치마다, 듣는 자리마다 다르게 들린다는 글입니다. 그 차이를 방이 소리가 전달되는 경로에 포함되느냐로 설명하고, 악기를 녹음할 때도 같은 일이 일어난다고 덧붙입니다.",
25: "2023~2025년 미국 소비자가 네 가지 후기 요청 방식(이메일, 대면, 소셜 미디어, 문자 메시지)에 응답할 의향을 보인 비율을 나타낸 막대 도표입니다. 선택지 문장들은 연도별·방식별 비율과 그 차이를 비교합니다.",
26: "영국 물리학자 Dennis William Sciama의 생애입니다. 가업을 잇기를 바란 아버지와 달리 학문의 길을 택했고, 우주 연구로 이름을 얻었으며, 1960년대 새 증거가 나오자 우주론에 대한 견해를 바꾸었습니다. 이후 메달을 받았고, 제자 Stephen Hawking을 다룬 영화로 대중에게도 알려졌습니다.",
27: "학생들이 1년 동안 온도 조절 시스템과 관수 드론으로 스마트 농장을 운영해 보는 프로그램 안내문입니다. 참가자가 해야 할 일(워크숍, 성장 일지, 멘토링, 최종 보고서), 우수 학생 혜택, 참가비와 지원 방식이 정리되어 있습니다.",
28: "주민 센터의 물건 대여 서비스 'Library of Things' 안내문입니다. 앱 로그인과 예약 방법, 물품 수령 요일, 빌릴 수 있는 물품, 대여 기간과 연장, 요금과 연체료가 담겨 있습니다.",
29: "산업 혁명이 새로운 기계뿐 아니라 '공장'이라는 제조 방식을 만들어 냈다는 글입니다. 1850년 무렵 이전의 피아노 가게는 도제식으로 한 대씩 만들었지만, 미국에서 Chickering과 Steinway 가문이 이끈 피아노 공장이 효율과 품질을 함께 높였다고 설명합니다.",
30: "논문 중심 박사 과정은 한 주제를 깊이 파고들게 해 주지만, 관련 분야를 살피거나 다른 기술을 익힐 시간이 줄어 지식과 기술의 폭이 좁아질 수 있다는 글입니다. 그래서 유럽 일부 대학이 수업·세미나·인턴십을 결합한 구조화된 과정을 도입했다는 흐름입니다.",
31: "세 살쯤 되면 아이들은 빈 상자에 연필을 상상해도 상자는 그대로 비어 있다는 것을 압니다. 그런데 어떤 경우에는 이 이해가 흔들린다면서, 침대 밑 괴물을 떠올린 아이나 빈 상자 속 괴물을 상상해 보라는 실험에 참여한 유치원생들의 반응을 예로 듭니다.",
32: "평범한 사물과 일상에서 얻는 미적 만족은 시인과 소설가에게는 오래전부터 인정받았지만 주류 철학에서는 무시되어 왔다는 데서 출발합니다. 이 '일상의 미학'의 현대적 뿌리를 John Dewey의 책에서 찾으며, Dewey가 미적 경험을 어디에서 찾았는지 소개합니다.",
33: "인간이 도덕적 행위자의 능력을 가졌다는 이유만으로 동식물보다 도덕적으로 우월하다고 말할 수 없다는 논증입니다. 도덕적으로 더 낫다·못하다는 판단이 어떤 조건에서만 성립하는지를 따져 보는 흐름입니다.",
34: "AI가 대화 중 짧은 침묵에 '음, 어' 같은 채움말을 넣으면 사람처럼 '생각하는' 듯 보인다는 글입니다. 동시에 긴 침묵은 잘 다루지 못하고 침묵을 소리로 채우려 하는 모습을 근거로, AI가 침묵을 어떻게 다루기 시작했는지와 여전한 한계를 함께 설명합니다.",
35: "인쇄술이 정보를 표준화했다는 주장을 마르코 폴로와 콜럼버스의 기록을 비교하며 설명하는 글입니다. 필사본으로 퍼진 폴로의 여행기는 판본마다 달라 어느 것이 진짜인지 알기 어렵지만, 인쇄된 콜럼버스의 편지는 한 가지 판본만 남았다는 흐름입니다.",
36: "주어진 글은 기원전 9500년 무렵 레반트 지역에서 이미 여러 작물을 재배했다는 내용입니다. (A)~(C)에는 정치·경제 요인과 줄어드는 농지 면적, 2050년 인구 전망과 농사에 적합한 땅의 한계, 오랜 기간의 농업 혁신과 계속 늘어나는 인구 이야기가 나뉘어 있습니다.",
37: "주어진 글은 언어를 비교할 때 '엄마, 아빠'처럼 어느 언어에나 있는 말부터 시작하면 좋다는 내용입니다. (A)~(C)에는 어떤 관계가 이름을 가질지 예측할 수 있다는 점과 핵심 용어, 다른 가족 관계를 더해 정의하는 '친족 용어' 범주와 연구 결과, 덜 중심적인 관계를 부르는 말이 만들어지는 방식이 나뉘어 있습니다.",
38: "가상 역할 놀이에서 참가자들이 허구 세계에 관한 정보를 서로 주고받는 방법을 다룬 글입니다. 역할에 몰입한 채 하는 말과 행동으로 전달하는 경우(피터 팬 놀이 예)와, 잠시 역할에서 빠져나와 정보를 알려 주는 경우(누가 어떤 역할인지 정리하는 예)가 나옵니다.",
39: "물질의 상태 변화에 대한 우리의 직관은 압력이 거의 일정한 지표면에서의 경험에서 나와, 녹거나 끓는 것을 온도 상승으로만 떠올린다는 글입니다. 이어서 물속이나 높은 산에서의 작은 압력 변화, 깊이에 따라 급격히 커지는 압력, 행성 전체의 엄청난 압력 범위로 이야기가 넓어집니다.",
40: "자가 실험과 전통적 실험의 차이를 '배우기'와 '보여 주기'의 차이에 빗대는 글입니다. 대부분의 과학자는 발견과 설득을 모두 원하므로, 연구자가 두 방식을 어떤 순서와 단계로 활용하면 자원을 가장 잘 쓸 수 있는지를 구체적으로 설명합니다.",
41: "19세기 사회 과학과 대규모 데이터의 등장으로 정보를 시각화하는 새로운 방식이 필요해졌다는 데서 시작합니다. 역사학은 주로 도표의 소비자였지만, 통계 분석이 정교해지면서 시각화가 논증의 중심이 되었고, 1854년 런던 콜레라 지도가 대표 사례로 소개된 뒤, 작가들이 시각적 단서로 복잡한 이야기를 전하려 한 시도로 이어집니다.",
43: "위대한 화가를 꿈꾸는 젊은 Aiden이 자연의 영혼을 그린다는 전설적인 화가 Rowan을 찾아가는 이야기입니다. (A)에서 Aiden은 그림을 품에 안고 Rowan의 오두막 문을 두드리고, (B)~(D)에는 Rowan이 건넨 평범한 돌, 그 돌을 오래 바라보는 시간, 완성한 그림을 들고 돌아가는 장면이 나뉘어 있습니다.",
}
