# 수능 당일 '빠른 정답 + 총평' 글 생성기 — 티스토리(T0)·해설노트(B0) 두 편, 문장을 서로 다르게
# 사용: python3 suneung_quick.py data.json  → out/sn_T0.html, out/sn_B0.html (+ _paste 버전)
# data.json 예:
# {"year":"2027학년도","date":"2026년 11월 19일","ans":"3 1 5 ... (45개)","pt3":[6,12,...],
#  "trend_listen":"...","trend_read":"...","hard":[[34,"빈칸","한 줄 이유"],...],"level":"작년 수능보다 다소 어려움",
#  "source":"한국교육과정평가원 정답 기준","links":{"T1":"...","B1":"..."}}
import json, sys, html
d = json.load(open(sys.argv[1], encoding='utf-8'))
N = "①②③④⑤"
A = [int(x) for x in d['ans'].split()]
assert len(A) == 45, len(A)
PT3 = set(d.get('pt3', []))
e = html.escape
NAVY, GREEN = "#1f4e79", "#1e5b45"
EBSI = "https://www.ebsi.co.kr"

def css(c):
    return f"""<style>
.sq{{font-family:'Noto Sans KR',sans-serif;max-width:760px;margin:0 auto;line-height:1.85;color:#222}}
.sq h2{{border-left:6px solid {c};padding-left:10px;margin:36px 0 12px;font-size:1.3em}}
.sq table{{border-collapse:collapse;width:100%;margin:10px 0;font-size:.95em}}
.sq th,.sq td{{border:1px solid #ccd;padding:5px 6px;text-align:center}} .sq th{{background:#eef3f9}}
.sq .box{{border:2px solid {c};border-radius:10px;padding:14px 18px;margin:16px 0;background:#fafcff}}
.sq .tip{{background:#fff7e6;border-left:4px solid #f0a020;padding:10px 14px;margin:14px 0}}
.sq .small{{color:#666;font-size:.9em}} .sq a{{color:{c};font-weight:700}}
</style>"""

def table():
    rows = ""
    for s in range(1, 46, 9):
        nums = range(s, min(s + 9, 46))
        rows += "<tr><th>번호</th>" + "".join(f"<th>{i}{'*' if i in PT3 else ''}</th>" for i in nums) + "</tr>"
        rows += "<tr><th>정답</th>" + "".join(f"<td>{N[A[i-1]-1]}</td>" for i in nums) + "</tr>"
    return f"<table>{rows}</table><p class='small'>* 3점 문항 · {e(d.get('source','한국교육과정평가원 발표 정답 기준'))}</p>"

def hard_list():
    return "<ol>" + "".join(f"<li><b>{n}번 ({e(t)})</b> — {e(w)}</li>" for n, t, w in d.get('hard', [])) + "</ol>"

L = d.get('links', {})
nxt_t = "".join(f"<li>{t}</li>" for t in [
    "11/20 — 정답 및 독해 18~30번 해설 (티스토리) · 빈칸 31~35번 해설 (해설노트)",
    "11/21 — 듣기 1~17번 해설 (티스토리) · 36~45번 해설 + 유사 문제 (해설노트)"])

T0 = f"""<div class="sq"><p class="small">{e(d['date'])} 시행 · {e(d['year'])} 대학수학능력시험 · 영어 영역</p>
<p>오늘 치러진 {e(d['year'])} 수능 영어 영역의 정답을 가장 먼저 정리했습니다. 가채점은 이 정답표로 하시고, 문항별 해설은 내일부터 순서대로 올라옵니다. 수험생 여러분, 정말 수고 많았습니다.</p>
<div class="box"><b>📥 공식 자료</b><br>문제지·듣기 음원·정답은 <a href="{EBSI}" target="_blank" rel="noopener">EBSi</a>와 한국교육과정평가원 누리집에서 받을 수 있습니다.</div>
<h2>1. 수능 영어 빠른 정답 (1~45번)</h2>{table()}
<h2>2. 한눈에 보는 총평</h2>
<p><b>전체 난이도</b> — {e(d['level'])}</p>
<p><b>듣기</b> — {e(d['trend_listen'])}</p>
<p><b>독해</b> — {e(d['trend_read'])}</p>
<h2>3. 점수를 가른 문항</h2>{hard_list()}
<div class="tip"><b>가채점할 때</b> — 마킹한 답을 시험지에 옮겨 적어 두었다면 이 표와 한 번, 공식 발표와 한 번 더 비교해 보세요. 영어는 절대평가라 원점수 90점 이상이면 1등급입니다.</div>
<h2>4. 앞으로 올라올 해설</h2><ul>{nxt_t}</ul>
</div>"""

B0 = f"""<div class="sq"><p class="small">{e(d['year'])} 수능 영어 · {e(d['date'])}</p>
<p>{e(d['year'])} 수능 영어 시험이 끝났습니다. 이 글은 '쌤의 영어 해설노트'에서 정리한 정답표와 유형별 짧은 분석입니다. 특히 오늘 많은 학생이 시간을 쏟았을 빈칸·순서·삽입 문항을 중심으로 보았습니다.</p>
<h2>정답표</h2>{table()}
<h2>쌤의 한 줄 분석</h2>
<p>체감 난이도는 <b>{e(d['level'])}</b> 정도로 봅니다.</p>
<p>독해 영역을 보면, {e(d['trend_read'])}</p>
<p>듣기 영역은 {e(d['trend_listen'])}</p>
<h2>다시 풀어 볼 고난도 문항</h2>{hard_list()}
<div class="tip">영어 등급은 원점수로 정해집니다(90점 이상 1등급, 80점 이상 2등급 …). 가채점 결과는 공식 정답 확정 공지와 꼭 다시 맞춰 보세요.</div>
<p class="small">문항별 해설은 11/20(빈칸 31~35번)과 11/21(36~45번 + 유사 문제)에 이 블로그에 올라옵니다.</p>
</div>"""

out = '/home/claude/mock3/out/'
for k, body, c in (("T0", T0, NAVY), ("B0", B0, GREEN)):
    open(f"{out}sn_{k}_paste.html", 'w', encoding='utf-8').write(css(c) + body)
    open(f"{out}sn_{k}.html", 'w', encoding='utf-8').write(f"<!doctype html><html lang='ko'><head><meta charset='utf-8'>{css(c)}</head><body style='padding:16px'>{body}</body></html>")
print("ok")
